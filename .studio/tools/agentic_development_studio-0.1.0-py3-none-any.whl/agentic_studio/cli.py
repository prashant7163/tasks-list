from __future__ import annotations

import json
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from agentic_studio.cli_parser import ParsedOperation, parse_studioctl
from agentic_studio.conformance import ConformanceRunner
from agentic_studio.context import RepositoryIndex
from agentic_studio.contracts import (
    RESULT_EXIT_CODES,
    ApproveRun,
    ArtifactKind,
    ArtifactSubmission,
    CommandResult,
    GateKind,
    ImportRun,
    InitializeRun,
    ResultCode,
    RunSelection,
    TaskLifecycle,
)
from agentic_studio.control.control_plane import ControlPlaneService
from agentic_studio.control.doctor import StudioDoctor
from agentic_studio.control.lifecycle import LifecycleController
from agentic_studio.generator import ProjectGenerator
from agentic_studio.progress import export_review, export_state


def _repository_root() -> Path:
    packaged_assets = Path(__file__).resolve().parent / "_assets"
    return packaged_assets if packaged_assets.is_dir() else Path(__file__).resolve().parents[2]


def _print_json(payload: object) -> None:
    print(json.dumps(payload, indent=2, sort_keys=True))


def studio_new_main(argv: Sequence[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(prog="studio-new")
    parser.add_argument("project_name")
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--runtime", choices=("codex",), default="codex")
    parser.add_argument("--source-root", type=Path, default=_repository_root())
    parser.add_argument("--git-init", action="store_true")
    arguments = parser.parse_args(argv)
    result = ProjectGenerator(arguments.source_root).generate(
        arguments.project_id,
        arguments.project_name,
        arguments.destination,
        arguments.runtime,
        git_init=arguments.git_init,
    )
    _print_json(
        {
            "destination": str(result.destination),
            "runtime": result.runtime,
            "file_count": len(result.files),
            "next_commands": [
                f"cd {result.destination}",
                "./studioctl bootstrap",
                "./studioctl doctor",
                "./studioctl status",
            ],
        }
    )
    return 0


def _load_request(root: Path, locator: str) -> dict[str, Any]:
    relative = Path(locator)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("operation file must be repository-relative")
    current = root
    for component in relative.parts:
        current /= component
        if current.is_symlink():
            raise ValueError("operation file cannot contain symbolic links")
    path = (root / relative).resolve(strict=True)
    path.relative_to(root)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("operation file must contain a JSON object")
    return payload


def _destination(root: Path, value: object) -> Path:
    path = Path(str(value))
    return path if path.is_absolute() else root / path


class StudioCtlMain:
    command_names = (
        "run",
        "specification",
        "plan",
        "evidence",
        "readiness",
        "task",
        "result",
        "gate",
        "status",
        "history",
        "explain",
        "progress",
        "resume",
        "retry",
        "cancel",
        "checkpoint",
        "projection-rebuild",
        "context-index-rebuild",
        "retention",
        "export-state",
        "export-review",
        "doctor",
        "control",
        "trust",
        "incident",
        "conformance",
        "bootstrap",
    )

    @staticmethod
    def _submission(
        service: ControlPlaneService,
        parameters: Mapping[str, Any],
        kind: ArtifactKind,
    ) -> CommandResult:
        return service.submit(
            ArtifactSubmission(
                kind=kind,
                file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
                gate_kind=(
                    GateKind(str(parameters["kind"])) if kind is ArtifactKind.GATE else None
                ),
            )
        )

    @staticmethod
    def _history(
        service: ControlPlaneService,
        parameters: Mapping[str, Any],
    ) -> CommandResult:
        run_id = parameters.get("run_id")
        limit = int(parameters.get("limit", 20))
        if limit < 0:
            raise ValueError("history limit must be non-negative")
        events = [
            event.model_dump(mode="json")
            for event in service.journal.replay()
            if run_id is None or event.run_id == run_id
        ]
        bounded = events[-limit:] if limit else []
        return CommandResult(
            code=ResultCode.OK,
            summary="Bounded authoritative history loaded.",
            details={"events": bounded},
        )

    def execute(self, parsed: ParsedOperation) -> CommandResult:
        root = parsed.project_root.resolve(strict=True)
        parameters = parsed.parameters
        service = ControlPlaneService(root)
        operation = parsed.operation

        if operation == "status":
            return service.status(parameters.get("run_id"))
        if operation == "run.initialize":
            return service.initialize_run(
                InitializeRun(
                    run_id=parameters.get("run_id"),
                    selected_runtime=str(parameters.get("runtime", "codex")),
                    idempotency_key=str(parameters["idempotency_key"]),
                )
            )
        if operation == "run.import":
            return service.import_run(
                ImportRun(
                    file=str(parameters["file"]),
                    idempotency_key=str(parameters["idempotency_key"]),
                )
            )
        if operation == "run.select":
            selected = parameters.get("run_id") or parameters.get("selected_run_id")
            if not isinstance(selected, str):
                raise ValueError("run select requires a run ID")
            return service.select_run(
                RunSelection(
                    run_id=selected,
                    idempotency_key=str(parameters["idempotency_key"]),
                )
            )
        if operation == "run.inspect":
            return service.status(parameters.get("run_id"))
        if operation == "run.approve":
            return service.approve_run(
                ApproveRun(
                    milestone_review_id=str(parameters["milestone_review_id"]),
                    milestone_review_sha256=str(parameters["milestone_review_sha256"]),
                    decision="approved",
                    decided_by=str(parameters["decided_by"]),
                    comment=parameters.get("comment"),
                    idempotency_key=str(parameters["idempotency_key"]),
                )
            )
        if operation == "run.list":
            projection = service.projections.load_or_rebuild()
            return CommandResult(
                code=ResultCode.OK,
                summary="Runs loaded from authoritative journal state.",
                details={
                    "active_run_id": projection.active_run_id,
                    "runs": [run.model_dump(mode="json") for run in projection.runs.values()],
                },
            )
        submission_kinds = {
            "specification.submit": ArtifactKind.SPECIFICATION,
            "plan.submit": ArtifactKind.PLAN,
            "evidence.submit": ArtifactKind.SUPPORTING_EVIDENCE,
            "readiness.submit": ArtifactKind.READINESS,
            "task.submit": ArtifactKind.TASK,
            "result.submit": ArtifactKind.RESULT,
            "gate.submit": ArtifactKind.GATE,
        }
        if operation in submission_kinds:
            return self._submission(service, parameters, submission_kinds[operation])
        if operation in {"readiness", "readiness.inspect"}:
            return service.status(parameters.get("run_id"))
        if operation == "history":
            return self._history(service, parameters)
        if operation == "explain":
            decision = LifecycleController().decide(
                TaskLifecycle(parameters["current"]),
                TaskLifecycle(parameters["requested"]),
                evidence_ids=parameters.get("evidence_id", ()),
            )
            return CommandResult(
                code=ResultCode.OK if decision.allowed else ResultCode.POLICY_DENIED,
                summary=decision.reason_code,
                details={
                    "allowed": decision.allowed,
                    "current": decision.current.value,
                    "requested": decision.requested.value,
                    "evidence_ids": list(decision.evidence_ids),
                },
            )
        if operation == "progress":
            return service.progress(
                limit=int(parameters.get("limit", 20)),
                run_id=parameters.get("run_id"),
            )
        if operation == "checkpoint.create":
            return service.create_checkpoint(
                file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
            )
        if operation in {"checkpoint", "checkpoint.inspect"}:
            return service.inspect_checkpoint(parameters.get("run_id"))
        if operation == "resume":
            return service.resume(
                file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
                resolution_evidence_ids=tuple(parameters.get("resolution_evidence", ())),
            )
        if operation == "retry":
            request = _load_request(root, str(parameters["file"]))
            task_id = request.get("task_id")
            if not isinstance(task_id, str):
                raise ValueError("retry file requires a task_id")
            evidence = request.get(
                "resolution_evidence_ids",
                parameters.get("resolution_evidence", ()),
            )
            if not isinstance(evidence, (list, tuple)):
                raise ValueError("retry resolution evidence must be a list")
            return service.retry(
                task_id=task_id,
                idempotency_key=str(parameters["idempotency_key"]),
                resolution_evidence_ids=tuple(str(item) for item in evidence),
            )
        if operation == "cancel":
            request = _load_request(root, str(parameters["file"]))
            force = request.get("force", False)
            reason = request.get("reason", "Operator requested cancellation.")
            if not isinstance(force, bool) or not isinstance(reason, str):
                raise ValueError("cancel file requires boolean force and string reason")
            return service.cancel(
                idempotency_key=str(parameters["idempotency_key"]),
                force=force,
                reason=reason,
            )
        if operation == "projection-rebuild":
            projection = service.projections.rebuild()
            if projection.active_run_id is None:
                return CommandResult(
                    code=ResultCode.NOT_INITIALIZED,
                    summary="Projection rebuilt; no active run is selected.",
                )
            run = projection.runs[projection.active_run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary="Derived projection rebuilt from the journal.",
                state=run.model_dump(mode="json"),
            )
        if operation == "context-index-rebuild":
            index_path = root / ".studio/context/index.json"
            snapshot = RepositoryIndex(root).build()
            RepositoryIndex(root).save(snapshot, index_path)
            return CommandResult(
                code=ResultCode.OK,
                summary="Redacted repository context index rebuilt.",
                details={
                    "revision": snapshot.revision,
                    "record_count": len(snapshot.records),
                },
            )
        if operation == "retention":
            return service.apply_retention(
                file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
            )
        if operation == "control.apply":
            return service.apply_control(
                file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
            )
        if operation == "control.clear":
            return service.clear_control(
                control_id=str(parameters["control_id"]),
                approval_file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
            )
        if operation in {"control", "control.inspect"}:
            return service.inspect_controls()
        if operation == "trust.apply":
            return service.apply_trust(
                file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
                approval_file=(
                    str(parameters["approval_file"])
                    if parameters.get("approval_file") is not None
                    else None
                ),
            )
        if operation in {"trust", "trust.inspect", "incident", "incident.inspect"}:
            status = service.status(parameters.get("run_id"))
            status_payload = status.model_dump(mode="json")
            return CommandResult(
                code=status.code,
                summary=f"{operation.split('.')[0].title()} state loaded.",
                state=status_payload["state"],
                next_action=status.next_action,
            )
        if operation == "incident.apply":
            return service.apply_incident(
                file=str(parameters["file"]),
                idempotency_key=str(parameters["idempotency_key"]),
            )
        if operation in {"export-state", "export-review"}:
            destination = _destination(root, parameters["destination"])
            if operation == "export-state":
                manifest = export_state(root, destination)
            else:
                status = service.status(parameters.get("run_id"))
                if status.code is not ResultCode.OK or status.state is None:
                    return status
                manifest = export_review(
                    root,
                    destination,
                    [item["snapshot_locator"] for item in status.state["artifacts"]],
                )
            return CommandResult(
                code=ResultCode.OK,
                summary=f"{operation.replace('-', ' ').title()} completed.",
                details={
                    "files": list(manifest.files),
                    "digests": dict(manifest.digests),
                },
            )
        if operation == "doctor":
            doctor = StudioDoctor(root).run(required_secret_references={})
            blocked = any(
                check.outcome.value == "affected_scope_blocker" for check in doctor.checks
            )
            return CommandResult(
                code=ResultCode.POLICY_DENIED if blocked else ResultCode.OK,
                summary="Studio doctor completed.",
                details={"doctor": doctor.model_dump(mode="json")},
            )
        if operation == "conformance":
            report = ConformanceRunner(root).run(write=False)
            return CommandResult(
                code=ResultCode.OK if report.passed else ResultCode.POLICY_DENIED,
                summary="Conformance evaluation completed.",
                details={"report": report.as_dict()},
            )
        if operation == "bootstrap":
            return CommandResult(
                code=ResultCode.POLICY_DENIED,
                summary="Project-local runtime bootstrap metadata is not installed.",
                next_action="Generate or install the pinned project runtime bundle.",
            )
        raise ValueError(f"unsupported operation: {operation}")

    def __call__(self, argv: Sequence[str] | None = None) -> int:
        arguments = list(argv) if argv is not None else sys.argv[1:]
        try:
            parsed = parse_studioctl(arguments)
            result = self.execute(parsed)
        except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as error:
            result = CommandResult(
                code=ResultCode.INVALID_INPUT,
                summary=(str(error).splitlines()[0] or type(error).__name__)[:500],
            )
        _print_json(result.model_dump(mode="json"))
        return RESULT_EXIT_CODES[result.code]


studioctl_main = StudioCtlMain()
