from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from .planning import ArtifactReference, _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class AssuranceOutcome(StrEnum):
    PASS = "pass"
    REVISION_REQUIRED = "revision_required"
    BLOCKED_INCONCLUSIVE = "blocked_inconclusive"


class ReviewOutcome(StrEnum):
    PASS = "pass"
    REVISION_REQUIRED = "revision_required"


class FindingState(StrEnum):
    OPEN = "open"
    REMEDIATED = "remediated"
    NOT_APPLICABLE_OR_INVALID = "not_applicable_or_invalid"


class Finding(_ImmutableStudioModel):
    finding_id: StableId
    severity: str = Field(min_length=1, max_length=40)
    locator: str = Field(min_length=1, max_length=500)
    category: str = Field(min_length=1, max_length=120)
    rationale: str = Field(min_length=1, max_length=500)
    recommendation: str = Field(min_length=1, max_length=500)
    evidence_reference: ArtifactReference
    disposition: FindingState = FindingState.OPEN

    @model_validator(mode="after")
    def validate_locator(self) -> Self:
        if not _is_safe_repo_locator(self.locator):
            raise ValueError("finding locator must be repository-relative")
        return self


class FindingDisposition(_ImmutableStudioModel):
    finding_id: StableId
    outcome: FindingState
    rationale: str = Field(min_length=1, max_length=500)
    evidence: list[ArtifactReference]

    @model_validator(mode="after")
    def validate_terminal_outcome(self) -> Self:
        if self.outcome is FindingState.OPEN:
            raise ValueError("finding disposition must be terminal")
        if self.outcome is FindingState.REMEDIATED and not self.evidence:
            raise ValueError("remediated finding requires evidence")
        return self


class CodeReview(_ImmutableContractModel):
    review_id: StableId
    task_id: StableId
    attempt_number: int = Field(ge=1)
    author_id: StableId
    reviewer_id: StableId
    candidate_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    binding_references: list[ArtifactReference]
    unit_test_references: list[ArtifactReference]
    findings: list[Finding]
    verdict: ReviewOutcome
    reviewed_at: AwareDatetime

    @model_validator(mode="after")
    def validate_review(self) -> Self:
        if self.author_id == self.reviewer_id:
            raise ValueError("code review must be independent of the author")
        if self.verdict is ReviewOutcome.PASS and any(
            finding.disposition is FindingState.OPEN for finding in self.findings
        ):
            raise ValueError("passing review cannot retain open findings")
        return self


class BuildStatus(_ImmutableContractModel):
    status_id: StableId
    recorded_at: AwareDatetime
    repository_id: StableId
    tested_snapshot_id: str = Field(pattern=r"^[0-9a-f]{64}$")
    pipeline_identity: str = Field(min_length=1, max_length=200)
    standards_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    trust_registry_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    integrity_check: str = Field(min_length=1, max_length=80)
    outcome: ReviewOutcome
    diagnostic_reference: ArtifactReference | None
    retry_count: int = Field(ge=0)
    likely_cause: str | None = None
    suspected_component: str | None = None
    next_action: str | None = None

    @model_validator(mode="after")
    def validate_failure_diagnostic(self) -> Self:
        if self.outcome is not ReviewOutcome.PASS and self.diagnostic_reference is None:
            raise ValueError("non-passing build requires a diagnostic reference")
        return self


class TouchpointResult(_ImmutableStudioModel):
    touchpoint_id: StableId
    kind: str = Field(min_length=1, max_length=120)
    evidence: list[ArtifactReference]
    outcome: AssuranceOutcome


class QualityEngineeringReport(_ImmutableContractModel):
    report_id: StableId
    project_id: StableId
    run_id: StableId
    session_id: StableId
    milestone_id: StableId
    task_ids: list[StableId] = Field(min_length=1)
    started_at: AwareDatetime
    completed_at: AwareDatetime
    prior_report_id: StableId | None
    tested_snapshot_id: str = Field(pattern=r"^[0-9a-f]{64}$")
    change_set_reference: ArtifactReference
    graph_reference: ArtifactReference
    graph_fresh: bool
    graph_confidence: str = Field(min_length=1, max_length=80)
    touchpoints: list[TouchpointResult] = Field(min_length=1)
    acceptance_ids: list[StableId]
    verification_scope: list[str] = Field(min_length=1)
    environment: dict[str, str]
    commands: list[str]
    exclusions: dict[str, str]
    residual_unknowns: list[str]
    findings: list[Finding]
    limitations: list[str]
    outcome: AssuranceOutcome

    @model_validator(mode="after")
    def validate_report(self) -> Self:
        if self.outcome is AssuranceOutcome.PASS:
            if self.residual_unknowns or self.limitations:
                raise ValueError("passing quality report cannot retain residual unknowns")
            if any(
                touchpoint.outcome is not AssuranceOutcome.PASS for touchpoint in self.touchpoints
            ):
                raise ValueError("passing quality report requires passing touchpoints")
            if any(finding.disposition is FindingState.OPEN for finding in self.findings):
                raise ValueError("passing quality report cannot retain open findings")
        return self


class IndependentAudit(_ImmutableContractModel):
    audit_id: StableId
    milestone_id: StableId
    author_ids: list[StableId]
    reviewer_ids: list[StableId]
    auditor_id: StableId
    candidate_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    traced_references: list[ArtifactReference]
    findings: list[Finding]
    dispositions: list[FindingDisposition]
    outcome: ReviewOutcome
    completed_at: AwareDatetime
    response_destination: str = Field(min_length=1, max_length=120)

    @model_validator(mode="after")
    def validate_audit(self) -> Self:
        if self.auditor_id in {*self.author_ids, *self.reviewer_ids}:
            raise ValueError("independent audit requires an independent auditor")
        if self.response_destination != "orchestrator":
            raise ValueError("independent audit must return only to orchestrator")
        dispositions = {item.finding_id: item for item in self.dispositions}
        if self.outcome is ReviewOutcome.PASS:
            for finding in self.findings:
                disposition = dispositions.get(finding.finding_id)
                if disposition is None or disposition.outcome is FindingState.OPEN:
                    raise ValueError("passing audit requires terminal finding dispositions")
                if finding.disposition != disposition.outcome:
                    raise ValueError("audit finding and disposition disagree")
        return self


class MilestoneReview(_ImmutableContractModel):
    review_id: StableId
    milestone_id: StableId
    candidate_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    readiness_reference: ArtifactReference
    contract_reference: ArtifactReference
    progress_reference: ArtifactReference
    code_review_references: list[ArtifactReference]
    build_status: BuildStatus
    quality_report: QualityEngineeringReport
    audit: IndependentAudit
    orchestrator_dispositions: list[FindingDisposition]
    open_comments: list[str]
    outcome: str = Field(min_length=1, max_length=120)

    @model_validator(mode="after")
    def validate_snapshot_binding(self) -> Self:
        snapshots = {
            self.candidate_digest,
            self.build_status.tested_snapshot_id,
            self.quality_report.tested_snapshot_id,
            self.audit.candidate_digest,
        }
        if len(snapshots) != 1:
            raise ValueError("milestone review evidence must bind the exact candidate")
        if self.outcome == "ready_for_user" and any(
            outcome != "pass"
            for outcome in (
                self.build_status.outcome,
                self.quality_report.outcome,
                self.audit.outcome,
            )
        ):
            raise ValueError("ready milestone review requires passing gate evidence")
        if self.outcome == "ready_for_user" and self.open_comments:
            raise ValueError("ready milestone review cannot retain open comments")
        return self
