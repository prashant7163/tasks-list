from __future__ import annotations

from enum import StrEnum
from typing import Any, Self

from pydantic import AwareDatetime, Field, model_validator

from .approval import ApprovalDecision
from .instances import AgentInstance, AgentLifecycle
from .planning import ArtifactReference, MilestoneBoundary, _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class ApplicabilityDecision(StrEnum):
    APPLICABLE = "applicable"
    NOT_APPLICABLE = "not_applicable"


class ReadinessOutcome(StrEnum):
    READY = "ready"
    REVISION_REQUIRED = "revision_required"


class RoleApplicability(_ImmutableStudioModel):
    role: str = Field(min_length=1, max_length=120)
    decision: ApplicabilityDecision
    rationale: str = Field(min_length=1, max_length=500)
    evidence_reference: ArtifactReference
    owner_instance_id: StableId | None = None

    @model_validator(mode="after")
    def validate_owner_assignment(self) -> Self:
        if self.decision is ApplicabilityDecision.APPLICABLE and self.owner_instance_id is None:
            raise ValueError("applicable role requires an owner instance")
        if (
            self.decision is ApplicabilityDecision.NOT_APPLICABLE
            and self.owner_instance_id is not None
        ):
            raise ValueError("not-applicable role cannot have an owner instance")
        return self


class ReadinessEvidence(_ImmutableStudioModel):
    decision: ApplicabilityDecision
    rationale: str = Field(min_length=1, max_length=500)
    evidence_references: list[ArtifactReference] = Field(min_length=1, max_length=8)

    @model_validator(mode="after")
    def validate_unique_evidence_references(self) -> Self:
        if len({item.artifact_id for item in self.evidence_references}) != len(
            self.evidence_references
        ):
            raise ValueError("duplicate evidence reference ID")
        return self


class EffectiveStandardsEvidence(ReadinessEvidence):
    applicable_standard_ids: list[StableId] = Field(default_factory=list)
    exception_ids: list[StableId] = Field(default_factory=list)


class RoleSkillIndependenceEvidence(ReadinessEvidence):
    covered_role_ids: list[StableId] = Field(default_factory=list)


class TrustedCapabilityEvidence(ReadinessEvidence):
    capability_ids: list[StableId] = Field(default_factory=list)


class ThreatDecisionEvidence(ReadinessEvidence):
    control_ids: list[StableId] = Field(default_factory=list)


class DoctorResultEvidence(ReadinessEvidence):
    redacted: bool = True

    @model_validator(mode="after")
    def validate_redaction(self) -> Self:
        if not self.redacted:
            raise ValueError("doctor result must be redacted")
        return self


class IntegrationTestPlanEvidence(ReadinessEvidence):
    integration_point_ids: list[StableId] = Field(default_factory=list)


class RollingProgressEvidence(ReadinessEvidence):
    pass


class InterfaceDecision(_ImmutableStudioModel):
    interface_id: StableId
    owner_instance_id: StableId
    work_package_id: StableId
    integration_reference: ArtifactReference
    reference: ArtifactReference
    example: str = Field(min_length=1, max_length=1000)


class WorkPackage(_ImmutableStudioModel):
    work_package_id: StableId
    owner_instance_id: StableId
    owned_locators: list[str] = Field(min_length=1, max_length=16)
    dependency_work_package_ids: list[StableId]
    sequence: int = Field(ge=1)
    deliverable: str = Field(min_length=1, max_length=1000)
    integration_references: list[ArtifactReference] = Field(min_length=1, max_length=16)

    @model_validator(mode="after")
    def validate_owned_locators(self) -> Self:
        if len(self.owned_locators) != len(set(self.owned_locators)) or any(
            not _is_safe_repo_locator(locator) for locator in self.owned_locators
        ):
            raise ValueError("work package requires unique safe owned locators")
        return self


def _locator_conflicts(left: str, right: str) -> bool:
    return left == right or left.startswith(f"{right}/") or right.startswith(f"{left}/")


def _validate_dependency_cycles(by_id: dict[str, WorkPackage]) -> None:
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(package_id: str) -> None:
        if package_id in visiting:
            raise ValueError("work package dependency cycle")
        if package_id in visited:
            return
        visiting.add(package_id)
        for dependency_id in sorted(by_id[package_id].dependency_work_package_ids):
            visit(dependency_id)
        visiting.remove(package_id)
        visited.add(package_id)

    for package_id in sorted(by_id):
        visit(package_id)


class MilestoneReadiness(_ImmutableContractModel):
    readiness_id: StableId
    outcome: ReadinessOutcome
    milestone_id: StableId | None = None
    specification_reference: ArtifactReference | None = None
    plan_reference: ArtifactReference | None = None
    effective_standards: EffectiveStandardsEvidence | None = None
    role_skill_independence: RoleSkillIndependenceEvidence | None = None
    trusted_capability: TrustedCapabilityEvidence | None = None
    threat_decision: ThreatDecisionEvidence | None = None
    doctor_result: DoctorResultEvidence | None = None
    integration_test_plan: IntegrationTestPlanEvidence | None = None
    rolling_progress: RollingProgressEvidence | None = None
    boundary: MilestoneBoundary | None = None
    role_applicability: list[RoleApplicability] = Field(default_factory=list)
    affected_roles: list[str] = Field(default_factory=list)
    approved_instances: list[AgentInstance] = Field(default_factory=list)
    acceptance_criterion_ids: list[StableId] = Field(default_factory=list)
    facilitator: str | None = None
    validated_at: AwareDatetime | None = None
    unresolved_items: list[str] = Field(default_factory=list)
    work_packages: list[WorkPackage] = Field(default_factory=list)
    interface_decisions: list[InterfaceDecision] = Field(default_factory=list)

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        schema = super().model_json_schema(*args, **kwargs)
        schema["x-agentic-studio-runtime-validation"] = {
            "canonical_validator": "MilestoneReadiness.validate_readiness",
            "required_rules": [
                "role_applicability_matches_affected_roles_and_approved_owners",
                "approved_instance_approval_and_envelope_binding",
                "replacement_predecessor_existence_lifecycle_approval_envelope",
                "work_package_owner_locator_overlap_dependency_cycle_sequence",
                "interface_owner_package_integration_binding",
                "readiness_evidence_reference_uniqueness",
            ],
        }
        return schema

    @model_validator(mode="after")
    def validate_readiness(self) -> Self:
        package_ids = [item.work_package_id for item in self.work_packages]
        if len(package_ids) != len(set(package_ids)):
            raise ValueError("duplicate work package ID")
        by_id = {item.work_package_id: item for item in self.work_packages}
        for item in self.work_packages:
            unknown = sorted(set(item.dependency_work_package_ids) - set(by_id))
            if unknown:
                raise ValueError(f"unknown work package dependencies: {unknown}")
            if item.work_package_id in item.dependency_work_package_ids:
                raise ValueError("self work package dependency")
            if len(item.dependency_work_package_ids) != len(set(item.dependency_work_package_ids)):
                raise ValueError("duplicate work package dependency")
        _validate_dependency_cycles(by_id)
        for item in self.work_packages:
            if any(
                by_id[dep].sequence >= item.sequence for dep in item.dependency_work_package_ids
            ):
                raise ValueError("work package sequence contradicts dependency")
        for package in self.work_packages:
            for other in self.work_packages:
                if package.work_package_id >= other.work_package_id:
                    continue
                if any(
                    _locator_conflicts(left, right)
                    for left in package.owned_locators
                    for right in other.owned_locators
                ):
                    raise ValueError("work package ownership conflict")
        if self.outcome is ReadinessOutcome.READY:
            required = [
                self.milestone_id,
                self.specification_reference,
                self.plan_reference,
                self.effective_standards,
                self.role_skill_independence,
                self.trusted_capability,
                self.threat_decision,
                self.doctor_result,
                self.integration_test_plan,
                self.rolling_progress,
                self.boundary,
                self.facilitator,
                self.validated_at,
            ]
            if any(value is None for value in required):
                raise ValueError(
                    "ready readiness requires typed readiness evidence and validation facts"
                )
            if not self.acceptance_criterion_ids or not self.approved_instances:
                raise ValueError(
                    "ready readiness requires acceptance and approved instance references"
                )
            if self.unresolved_items:
                raise ValueError("ready readiness cannot contain unresolved items")
            if len(self.affected_roles) != len(set(self.affected_roles)):
                raise ValueError("duplicate affected role")
            decisions = {item.role: item for item in self.role_applicability}
            if len(decisions) != len(self.role_applicability):
                raise ValueError("duplicate role applicability decision")
            applicable_roles = {
                role
                for role, decision in decisions.items()
                if decision.decision is ApplicabilityDecision.APPLICABLE
            }
            if applicable_roles != set(self.affected_roles):
                raise ValueError("affected roles must exactly match applicable role decisions")
            instances = {item.agent_instance_id: item for item in self.approved_instances}
            if len(instances) != len(self.approved_instances):
                raise ValueError("duplicate approved instance")
            for role, decision in decisions.items():
                if decision.decision is ApplicabilityDecision.NOT_APPLICABLE:
                    continue
                if decision.owner_instance_id is None:
                    raise ValueError("applicable role requires an owner instance")
                owner = instances.get(decision.owner_instance_id)
                if owner is None or owner.role_template_id != role:
                    raise ValueError("role owner must bind an approved instance")
            if len(
                {item.owner_instance_id for item in decisions.values() if item.owner_instance_id}
            ) != len(self.affected_roles):
                raise ValueError("affected roles require distinct approved owners")
            evidence_references = _readiness_evidence_references(self)
            if len({item.artifact_id for item in evidence_references}) != len(evidence_references):
                raise ValueError("duplicate readiness evidence reference ID")
            for package in self.work_packages:
                if package.owner_instance_id not in instances:
                    raise ValueError("work package owner must bind an approved instance")
            if not self.work_packages:
                raise ValueError("ready readiness requires a bounded work package")
            interface_ids = [item.interface_id for item in self.interface_decisions]
            if len(interface_ids) != len(set(interface_ids)):
                raise ValueError("duplicate interface decision ID")
            for interface in self.interface_decisions:
                responsible_package = by_id.get(interface.work_package_id)
                if responsible_package is None:
                    raise ValueError("interface work package is unknown")
                if interface.owner_instance_id not in instances or (
                    interface.owner_instance_id != responsible_package.owner_instance_id
                ):
                    raise ValueError("interface owner must bind its approved package owner")
                if (
                    interface.integration_reference
                    not in responsible_package.integration_references
                ):
                    raise ValueError("interface integration responsibility is unknown")
            if not self.interface_decisions:
                raise ValueError("ready readiness requires interface decisions")
            if self.boundary is MilestoneBoundary.SINGLE_ROLE and len(self.affected_roles) != 1:
                raise ValueError("single-role readiness requires exactly one owner")
            if self.boundary is MilestoneBoundary.CROSS_BOUNDARY and len(self.affected_roles) < 2:
                raise ValueError("cross-boundary readiness requires affected roles")
            for instance in self.approved_instances:
                if (
                    instance.approval is None
                    or instance.approval.decision is not ApprovalDecision.APPROVED
                ):
                    raise ValueError("approved instance requires exact approved approval")
                if instance.replacement_for_instance_id is not None:
                    predecessor = instances.get(instance.replacement_for_instance_id)
                    if predecessor is None or predecessor.lifecycle not in {
                        AgentLifecycle.INTERRUPTED,
                        AgentLifecycle.RETIRED,
                    }:
                        raise ValueError("replacement requires eligible authoritative predecessor")
                    if instance.approval != predecessor.approval or (
                        instance.approval_envelope_digest()
                        != predecessor.approval_envelope_digest()
                    ):
                        raise ValueError("replacement must reuse exact approval and envelope")
        return self


class ContractSnapshot(_ImmutableContractModel):
    snapshot_id: StableId
    snapshot_version: str = Field(pattern=r"^1\.\d+\.\d+$")
    source_snapshot: str = Field(pattern=r"^[0-9a-f]{40}$")
    authors: list[str] = Field(min_length=1, max_length=16)
    readiness: MilestoneReadiness
    readiness_reference: ArtifactReference
    plan_reference: ArtifactReference
    specification_reference: ArtifactReference
    evidence_references: list[ArtifactReference] = Field(min_length=1, max_length=64)
    work_package_ids: list[StableId] = Field(min_length=1)
    interface_decisions: list[InterfaceDecision] = Field(min_length=1)
    validated_at: AwareDatetime

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        schema = super().model_json_schema(*args, **kwargs)
        schema["x-agentic-studio-runtime-validation"] = {
            "canonical_validator": "ContractSnapshot.validate_snapshot",
            "required_rules": [
                "readiness_digest_identity_and_ready_outcome",
                "plan_specification_and_evidence_reference_equality",
                "exact_work_package_and_interface_assignment_sets",
                "interface_owner_package_integration_binding",
                "snapshot_duplicate_reference_rejection",
                "snapshot_validation_time_not_before_readiness",
            ],
        }
        return schema

    @model_validator(mode="after")
    def validate_snapshot(self) -> Self:
        if self.readiness.outcome is not ReadinessOutcome.READY:
            raise ValueError("snapshot requires ready readiness")
        if (
            self.readiness_reference.artifact_id != self.readiness.readiness_id
            or self.readiness_reference.sha256 != self.readiness.sha256_digest()
        ):
            raise ValueError("snapshot readiness digest or identity does not match")
        if self.plan_reference != self.readiness.plan_reference:
            raise ValueError("snapshot plan reference does not match readiness")
        if self.specification_reference != self.readiness.specification_reference:
            raise ValueError("snapshot specification reference does not match readiness")
        expected_evidence = _readiness_evidence_references(self.readiness)
        if len({item.artifact_id for item in self.evidence_references}) != len(
            self.evidence_references
        ):
            raise ValueError("duplicate snapshot evidence reference ID")
        if [item.model_dump(mode="json") for item in self.evidence_references] != [
            item.model_dump(mode="json") for item in expected_evidence
        ]:
            raise ValueError("snapshot evidence references do not match readiness")
        if len(self.work_package_ids) != len(set(self.work_package_ids)):
            raise ValueError("duplicate snapshot work package assignment")
        if set(self.work_package_ids) != {
            package.work_package_id for package in self.readiness.work_packages
        }:
            raise ValueError("snapshot work package assignments do not match readiness")
        interface_ids = [item.interface_id for item in self.interface_decisions]
        if len(interface_ids) != len(set(interface_ids)):
            raise ValueError("duplicate interface decision ID")
        if self.interface_decisions != self.readiness.interface_decisions:
            raise ValueError("snapshot interface decisions do not match readiness")
        if self.readiness.validated_at is None or self.validated_at < self.readiness.validated_at:
            raise ValueError("snapshot validation cannot predate readiness")
        return self


def _readiness_evidence_references(readiness: MilestoneReadiness) -> list[ArtifactReference]:
    evidence = (
        readiness.effective_standards,
        readiness.role_skill_independence,
        readiness.trusted_capability,
        readiness.threat_decision,
        readiness.doctor_result,
        readiness.integration_test_plan,
        readiness.rolling_progress,
    )
    return [
        reference for item in evidence if item is not None for reference in item.evidence_references
    ]
