from __future__ import annotations

from enum import StrEnum
from typing import Any, Self

from pydantic import Field, model_validator

from .approval import Approval, ApprovalDecision
from .planning import ArtifactReference, WorkspaceAllocation
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class ContextAccessMode(StrEnum):
    MINIMUM_NECESSARY = "minimum_necessary"


class AgentLifecycle(StrEnum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    INTERRUPTED = "interrupted"
    RETIRED = "retired"


class ProposalDecision(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    DECLINED = "declined"
    CANCELLED = "cancelled"


class Specialization(_ImmutableStudioModel):
    specialization_id: StableId
    parameters: list[str] = Field(min_length=1, max_length=16)

    @model_validator(mode="after")
    def validate_parameters(self) -> Self:
        _validate_entries(self.parameters, "specialization parameters")
        return self


class PermissionEnvelope(_ImmutableStudioModel):
    data_allowlist: list[str] = Field(max_length=32)
    tool_allowlist: list[str] = Field(max_length=32)

    @model_validator(mode="after")
    def validate_allowlists(self) -> Self:
        _validate_entries(self.data_allowlist, "data allowlist")
        _validate_entries(self.tool_allowlist, "tool allowlist")
        return self


class ProviderModelConstraints(_ImmutableStudioModel):
    provider_allowlist: list[str] = Field(min_length=1, max_length=16)
    model_allowlist: list[str] = Field(min_length=1, max_length=32)

    @model_validator(mode="after")
    def validate_allowlists(self) -> Self:
        _validate_entries(self.provider_allowlist, "provider allowlist")
        _validate_entries(self.model_allowlist, "model allowlist")
        return self


class BudgetEnvelope(_ImmutableStudioModel):
    max_concurrency: int = Field(gt=0)
    max_cost_units: int = Field(gt=0)
    max_duration_minutes: int = Field(gt=0)


class LeaseEnvelope(_ImmutableStudioModel):
    lifetime_minutes: int = Field(gt=0)
    handoff_condition: str = Field(min_length=1, max_length=500)
    cleanup_condition: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_text(self) -> Self:
        _validate_text(self.handoff_condition, self.cleanup_condition)
        return self


def _validate_entries(values: list[str], label: str) -> None:
    if any(not value.strip() or len(value) > 120 for value in values):
        raise ValueError(f"{label} entries must be nonblank and bounded")
    if len(values) != len(set(values)):
        raise ValueError(f"duplicate {label} entry")


def _validate_text(*values: str) -> None:
    if any(not value.strip() for value in values):
        raise ValueError("externally supplied text must be nonblank")


class _InstanceEnvelope(_ImmutableContractModel):
    role_template_id: StableId
    specialization: Specialization
    scope: str = Field(min_length=1, max_length=2000)
    deliverable: str = Field(min_length=1, max_length=2000)
    ownership_boundary: str = Field(min_length=1, max_length=500)
    overlap_check: str = Field(min_length=1, max_length=500)
    context_access_mode: ContextAccessMode
    permissions: PermissionEnvelope
    workspace: WorkspaceAllocation
    provider_model: ProviderModelConstraints
    budget: BudgetEnvelope
    lease: LeaseEnvelope
    reason_trigger: str = Field(min_length=1, max_length=500)
    dependency_references: list[ArtifactReference] = Field(min_length=1, max_length=32)
    contract_references: list[ArtifactReference] = Field(min_length=1, max_length=32)
    work_package_references: list[ArtifactReference] = Field(min_length=1, max_length=32)
    minimum_context_pack_reference: ArtifactReference

    @model_validator(mode="after")
    def validate_envelope_text(self) -> Self:
        _validate_text(
            self.scope,
            self.deliverable,
            self.ownership_boundary,
            self.overlap_check,
            self.reason_trigger,
        )
        return self

    def approval_envelope_digest(self) -> str:
        return self.sha256_digest(exclude=self._approval_envelope_exclusions())

    def _approval_envelope_exclusions(self) -> set[str]:
        return {"schema_version"}


class AgentInstance(_InstanceEnvelope):
    agent_instance_id: StableId
    lifecycle: AgentLifecycle
    approval: Approval | None
    replacement_for_instance_id: StableId | None = None

    def _approval_envelope_exclusions(self) -> set[str]:
        return {
            "schema_version",
            "agent_instance_id",
            "lifecycle",
            "approval",
            "replacement_for_instance_id",
        }

    def approval_subject_digest(self) -> str:
        return self.approval_envelope_digest()

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        schema = super().model_json_schema(*args, **kwargs)
        schema["x-agentic-studio-runtime-validation"] = {
            "canonical_validator": "AgentInstance.validate_lifecycle_and_approval",
            "required_rules": [
                "authoritative readiness/control-plane state confirms predecessor "
                "instance existence",
                "authoritative readiness/control-plane state confirms predecessor "
                "approval eligibility",
            ],
        }
        return schema

    @model_validator(mode="after")
    def validate_lifecycle_and_approval(self) -> Self:
        approval_required = self.lifecycle in {AgentLifecycle.ACTIVE, AgentLifecycle.COMPLETED}
        if approval_required and self.approval is None:
            raise ValueError("active or completed instance requires approval")
        if self.approval is not None:
            if self.approval.decision is not ApprovalDecision.APPROVED:
                raise ValueError("instance approval must be approved")
            if self.approval.subject_type != "agent_instance":
                raise ValueError("instance approval subject type does not match")
            expected_subject_id = self.replacement_for_instance_id or self.agent_instance_id
            if self.approval.subject_id != expected_subject_id:
                raise ValueError("instance approval subject ID does not match")
            if self.approval.subject_digest != self.approval_subject_digest():
                raise ValueError("instance approval digest does not match")
        return self


class SpawnProposal(_InstanceEnvelope):
    proposal_id: StableId
    decision: ProposalDecision
    approval: Approval | None
    why_existing_cannot_cover: str = Field(min_length=1, max_length=500)
    consequence_of_declining: str = Field(min_length=1, max_length=500)
    orchestrator_recommendation: str = Field(min_length=1, max_length=500)

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        schema = super().model_json_schema(*args, **kwargs)
        schema["x-agentic-studio-runtime-validation"] = {
            "canonical_validator": "SpawnProposal.validate_decision_and_approval",
            "required_rules": [
                "proposal decision and exact approval subject/digest coherence",
                "approved envelope digest excludes proposal identity and decision state",
            ],
        }
        return schema

    @model_validator(mode="after")
    def validate_proposal_text(self) -> Self:
        _validate_text(
            self.why_existing_cannot_cover,
            self.consequence_of_declining,
            self.orchestrator_recommendation,
        )
        return self

    def _approval_envelope_exclusions(self) -> set[str]:
        return {"schema_version", "proposal_id", "decision", "approval"}

    def approval_subject_digest(self) -> str:
        return self.sha256_digest(exclude={"decision", "approval"})

    @model_validator(mode="after")
    def validate_decision_and_approval(self) -> Self:
        if self.decision is ProposalDecision.PENDING:
            if self.approval is not None:
                raise ValueError("pending proposal cannot contain approval")
            return self
        if self.decision is ProposalDecision.APPROVED and self.approval is None:
            raise ValueError("approved proposal requires approval")
        if self.approval is None:
            return self
        if self.approval.subject_type != "spawn_proposal":
            raise ValueError("proposal approval subject type does not match")
        if self.approval.subject_id != self.proposal_id:
            raise ValueError("proposal approval subject ID does not match")
        if self.approval.subject_digest != self.approval_subject_digest():
            raise ValueError("proposal approval digest does not match")
        if self.decision is ProposalDecision.APPROVED:
            if self.approval.decision is not ApprovalDecision.APPROVED:
                raise ValueError("approved proposal requires approved decision")
        elif self.approval.decision is ApprovalDecision.APPROVED:
            raise ValueError("declined or cancelled proposal cannot have approving decision")
        return self
