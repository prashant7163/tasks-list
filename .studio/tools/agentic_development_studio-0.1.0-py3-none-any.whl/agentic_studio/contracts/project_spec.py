from collections.abc import Mapping
from enum import StrEnum
from typing import Annotated, Any, Self

from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    model_serializer,
    model_validator,
)

from .approval import (
    Approval,
    ApprovalDecision,
    _freeze_extras,
    _freeze_json,
    _FrozenJsonMapping,
    _FrozenJsonSequence,
    _thaw_extras,
    _thaw_json,
)
from .base import ContractModel, StudioModel

StableId = Annotated[str, Field(pattern=r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")]
ShortText = Annotated[str, Field(min_length=1, max_length=500)]


def _freeze_declared_value(value: Any) -> Any:
    if isinstance(value, list):
        return tuple(_freeze_declared_value(item) for item in value)
    if isinstance(value, dict):
        return _freeze_json(value, set())
    return value


def _thaw_declared_value(value: Any) -> Any:
    if isinstance(value, tuple):
        return [_thaw_declared_value(item) for item in value]
    if isinstance(value, (_FrozenJsonMapping, _FrozenJsonSequence)):
        return _thaw_json(value)
    return value


def _freeze_snapshot(model: StudioModel) -> None:
    for field_name in type(model).model_fields:
        object.__setattr__(
            model,
            field_name,
            _freeze_declared_value(getattr(model, field_name)),
        )
    if model.__pydantic_extra__ is not None:
        object.__setattr__(model, "__pydantic_extra__", _freeze_extras(model.__pydantic_extra__))


def _serialize_snapshot(model: StudioModel, handler: SerializerFunctionWrapHandler) -> Any:
    serialization_copy = BaseModel.__copy__(model)
    for field_name in type(model).model_fields:
        object.__setattr__(
            serialization_copy,
            field_name,
            _thaw_declared_value(getattr(model, field_name)),
        )
    if model.__pydantic_extra__ is not None:
        object.__setattr__(
            serialization_copy,
            "__pydantic_extra__",
            _thaw_extras(model.__pydantic_extra__),
        )
    return handler(serialization_copy)


def _snapshot_clone[SnapshotModel: StudioModel](
    model: SnapshotModel,
    update: Mapping[str, Any] | None = None,
) -> SnapshotModel:
    payload = model.model_dump(mode="json", round_trip=True)
    if update is not None:
        payload.update(update)
    return type(model).model_validate(payload)


class _ImmutableStudioModel(StudioModel):
    model_config = ConfigDict(extra="allow", frozen=True, validate_default=True)

    def model_post_init(self, __context: Any) -> None:
        _freeze_snapshot(self)

    @model_serializer(mode="wrap")
    def serialize_model(self, handler: SerializerFunctionWrapHandler) -> Any:
        return _serialize_snapshot(self, handler)

    def __copy__(self) -> Self:
        return _snapshot_clone(self)

    def __deepcopy__(self, memo: dict[int, Any] | None = None) -> Self:
        return _snapshot_clone(self)

    def model_copy(
        self,
        *,
        update: Mapping[str, Any] | None = None,
        deep: bool = False,
    ) -> Self:
        return _snapshot_clone(self, update)


class _ImmutableContractModel(ContractModel):
    model_config = ConfigDict(extra="allow", frozen=True, validate_default=True)

    def model_post_init(self, __context: Any) -> None:
        _freeze_snapshot(self)

    @model_serializer(mode="wrap")
    def serialize_model(self, handler: SerializerFunctionWrapHandler) -> Any:
        return _serialize_snapshot(self, handler)

    def __copy__(self) -> Self:
        return _snapshot_clone(self)

    def __deepcopy__(self, memo: dict[int, Any] | None = None) -> Self:
        return _snapshot_clone(self)

    def model_copy(
        self,
        *,
        update: Mapping[str, Any] | None = None,
        deep: bool = False,
    ) -> Self:
        return _snapshot_clone(self, update)


class SpecificationStatus(StrEnum):
    DRAFT = "draft"
    APPROVED = "approved"


class NonFunctionalCategory(StrEnum):
    SECURITY = "security"
    PRIVACY = "privacy"
    ACCESSIBILITY = "accessibility"
    PERFORMANCE = "performance"
    RELIABILITY = "reliability"
    OPERABILITY = "operability"
    MAINTAINABILITY = "maintainability"


class ProjectIdentity(_ImmutableStudioModel):
    project_id: StableId
    name: ShortText
    slug: StableId
    owner: ShortText
    created_at: AwareDatetime


class Persona(_ImmutableStudioModel):
    persona_id: StableId
    name: ShortText
    needs: list[ShortText]


class Journey(_ImmutableStudioModel):
    journey_id: StableId
    persona_id: StableId
    outcome: ShortText
    steps: list[ShortText] = Field(min_length=1)


class Goal(_ImmutableStudioModel):
    goal_id: StableId
    statement: ShortText


class SuccessCriterion(_ImmutableStudioModel):
    criterion_id: StableId
    statement: ShortText
    measurement: ShortText


class AcceptanceCriterion(_ImmutableStudioModel):
    criterion_id: StableId
    statement: ShortText


class Requirement(_ImmutableStudioModel):
    requirement_id: StableId
    statement: ShortText
    acceptance_criteria: list[AcceptanceCriterion] = Field(min_length=1)


class NonFunctionalRequirement(Requirement):
    category: NonFunctionalCategory


class StackAlternative(_ImmutableStudioModel):
    name: ShortText
    rationale: ShortText


class StackChoice(_ImmutableStudioModel):
    components: list[ShortText] = Field(min_length=1)
    alternatives: list[StackAlternative]
    rationale: ShortText


class ExternalSystem(_ImmutableStudioModel):
    system_id: StableId
    name: ShortText
    purpose: ShortText
    data_classifications: list[ShortText]


class TraceabilityEntry(_ImmutableStudioModel):
    traceability_id: StableId
    requirement_id: StableId
    acceptance_criterion_ids: list[StableId] = Field(min_length=1)


class ProjectSpecification(_ImmutableContractModel):
    identity: ProjectIdentity
    status: SpecificationStatus
    problem_statement: ShortText
    desired_outcome: ShortText
    personas: list[Persona] = Field(min_length=1)
    primary_journeys: list[Journey] = Field(min_length=1)
    goals: list[Goal] = Field(min_length=1)
    success_criteria: list[SuccessCriterion] = Field(min_length=1)
    non_goals: list[ShortText]
    scope_included: list[ShortText] = Field(min_length=1)
    scope_excluded: list[ShortText]
    functional_requirements: list[Requirement] = Field(min_length=1)
    non_functional_requirements: list[NonFunctionalRequirement]
    chosen_stack: StackChoice
    ux_flow_references: list[str]
    responsive_behavior: str | None
    design_system_direction: str | None
    external_systems: list[ExternalSystem]
    data_classifications: list[ShortText]
    assumptions: list[ShortText]
    constraints: list[ShortText]
    risks: list[ShortText]
    dependencies: list[ShortText]
    threat_model_required: bool
    threat_model_reference: str | None
    standards_profile_ids: list[StableId]
    open_questions: list[ShortText]
    traceability: list[TraceabilityEntry]
    approval: Approval | None

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        schema = super().model_json_schema(*args, **kwargs)
        schema["allOf"] = [
            {
                "if": {"properties": {"status": {"const": "draft"}}, "required": ["status"]},
                "then": {
                    "properties": {"approval": {"type": "null"}},
                    "required": ["approval"],
                },
            },
            {
                "if": {"properties": {"status": {"const": "approved"}}, "required": ["status"]},
                "then": {
                    "properties": {
                        "approval": {
                            "allOf": [{"$ref": "#/$defs/Approval"}],
                            "properties": {
                                "decision": {"const": "approved"},
                                "subject_type": {"const": "project_specification"},
                            },
                        },
                        "open_questions": {"maxItems": 0},
                    },
                    "required": ["approval", "open_questions"],
                },
            },
            {
                "if": {
                    "allOf": [
                        {"properties": {"status": {"const": "approved"}}, "required": ["status"]},
                        {
                            "properties": {"threat_model_required": {"const": True}},
                            "required": ["threat_model_required"],
                        },
                    ]
                },
                "then": {
                    "properties": {"threat_model_reference": {"type": "string"}},
                    "required": ["threat_model_reference"],
                },
            },
        ]
        schema["x-agentic-studio-runtime-validation"] = {
            "canonical_validator": "ProjectSpecification.validate_traceability_and_approval",
            "required_rules": [
                "approval.subject_id equals identity.project_id",
                "approval.subject_digest equals canonical approval_digest",
                "requirement, acceptance, traceability, and named-reference uniqueness/ownership",
            ],
        }
        return schema

    def approval_digest(self) -> str:
        return self.sha256_digest(exclude={"status", "approval"})

    @model_validator(mode="after")
    def validate_traceability_and_approval(self) -> Self:
        requirements = [*self.functional_requirements, *self.non_functional_requirements]
        requirement_ids = [item.requirement_id for item in requirements]
        if len(requirement_ids) != len(set(requirement_ids)):
            raise ValueError("duplicate requirement ID")

        acceptance_ids = [
            criterion.criterion_id
            for requirement in requirements
            for criterion in requirement.acceptance_criteria
        ]
        if len(acceptance_ids) != len(set(acceptance_ids)):
            raise ValueError("duplicate acceptance criterion ID")

        for entry in self.traceability:
            if len(entry.acceptance_criterion_ids) != len(set(entry.acceptance_criterion_ids)):
                raise ValueError("duplicate traceability acceptance criterion ID")

        trace_by_requirement = {item.requirement_id: item for item in self.traceability}
        if len(trace_by_requirement) != len(self.traceability):
            raise ValueError("duplicate traceability requirement mapping")

        traceability_ids = [item.traceability_id for item in self.traceability]
        if len(traceability_ids) != len(set(traceability_ids)):
            raise ValueError("duplicate traceability ID")

        missing = sorted(set(requirement_ids) - set(trace_by_requirement))
        unknown = sorted(set(trace_by_requirement) - set(requirement_ids))
        if missing:
            raise ValueError(f"missing traceability for requirements: {missing}")
        if unknown:
            raise ValueError(f"unknown traceability requirements: {unknown}")

        for requirement in requirements:
            expected = {item.criterion_id for item in requirement.acceptance_criteria}
            actual = set(trace_by_requirement[requirement.requirement_id].acceptance_criterion_ids)
            if actual != expected:
                raise ValueError(f"acceptance traceability mismatch: {requirement.requirement_id}")

        persona_ids = {persona.persona_id for persona in self.personas}
        if len(persona_ids) != len(self.personas):
            raise ValueError("duplicate persona ID")
        journey_ids = [journey.journey_id for journey in self.primary_journeys]
        if len(journey_ids) != len(set(journey_ids)):
            raise ValueError("duplicate journey ID")
        goal_ids = [goal.goal_id for goal in self.goals]
        if len(goal_ids) != len(set(goal_ids)):
            raise ValueError("duplicate goal ID")
        success_criterion_ids = [criterion.criterion_id for criterion in self.success_criteria]
        if len(success_criterion_ids) != len(set(success_criterion_ids)):
            raise ValueError("duplicate success criterion ID")
        external_system_ids = [system.system_id for system in self.external_systems]
        if len(external_system_ids) != len(set(external_system_ids)):
            raise ValueError("duplicate external system ID")
        unknown_personas = sorted(
            {journey.persona_id for journey in self.primary_journeys} - persona_ids
        )
        if unknown_personas:
            raise ValueError(f"unknown journey personas: {unknown_personas}")

        if self.status is SpecificationStatus.DRAFT:
            if self.approval is not None:
                raise ValueError("draft specification cannot contain approval")
            return self

        if self.open_questions:
            raise ValueError("open_questions must be empty before approval")
        if self.threat_model_required and self.threat_model_reference is None:
            raise ValueError("approved specification requires threat model reference")
        if self.approval is None:
            raise ValueError("approved specification requires approval")
        if self.approval.decision is not ApprovalDecision.APPROVED:
            raise ValueError("approved specification requires approved decision")
        if self.approval.subject_type != "project_specification":
            raise ValueError("approval subject type does not match")
        if self.approval.subject_id != self.identity.project_id:
            raise ValueError("approval subject ID does not match")
        if self.approval.subject_digest != self.approval_digest():
            raise ValueError("approval digest does not match")
        return self
