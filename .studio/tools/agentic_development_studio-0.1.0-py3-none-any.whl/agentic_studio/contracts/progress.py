from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from .planning import ArtifactReference, _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class ChangeAction(StrEnum):
    ADD = "add"
    CHANGE = "change"
    REMOVE = "remove"


class ChangeIntentStatus(StrEnum):
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    DIVERGED = "diverged"


class StepStatus(StrEnum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETE = "complete"
    BLOCKED = "blocked"


class MilestoneProgressStatus(StrEnum):
    PLANNED = "planned"
    ACTIVE = "active"
    BLOCKED = "blocked"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    CANCELLED = "cancelled"


class BlastRadius(_ImmutableContractModel):
    blast_radius_id: StableId
    graph_snapshot_id: str = Field(pattern=r"^[0-9a-f]{64}$")
    graph_fresh: bool
    affected_code: list[str]
    affected_contracts: list[str]
    affected_tests: list[str]
    affected_owners: list[str]
    affected_build_paths: list[str]
    confidence: str = Field(min_length=1, max_length=80)
    unknown_edges: list[str]
    verification_plan: list[str] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_paths(self) -> Self:
        paths = (*self.affected_code, *self.affected_tests, *self.affected_build_paths)
        if any(not _is_safe_repo_locator(path) for path in paths):
            raise ValueError("blast-radius paths must be repository-relative")
        return self


class BlastRadiusExemption(_ImmutableContractModel):
    exemption_id: StableId
    intent_id: StableId
    classification: str = Field(min_length=1, max_length=120)
    rationale: str = Field(min_length=1, max_length=500)
    reviewer_id: StableId | None = None
    evidence_references: list[ArtifactReference]


class ChangeIntent(_ImmutableContractModel):
    intent_id: StableId
    target: str = Field(min_length=1, max_length=500)
    locator: str = Field(min_length=1, max_length=500)
    action: ChangeAction
    necessity: str = Field(min_length=1, max_length=500)
    why_here: str = Field(min_length=1, max_length=500)
    affected_contracts: list[str]
    protected: bool = False
    blast_radius_reference: ArtifactReference | None
    exemption_reference: ArtifactReference | None
    verification: list[str] = Field(min_length=1)
    status: ChangeIntentStatus
    divergence_reason: str | None = Field(default=None, min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_analysis(self) -> Self:
        if not _is_safe_repo_locator(self.locator):
            raise ValueError("change locator must be repository-relative")
        if self.protected and self.blast_radius_reference is None:
            raise ValueError("protected change requires blast radius analysis")
        if self.protected and self.exemption_reference is not None:
            raise ValueError("protected change cannot use a blast radius exemption")
        if (
            not self.protected
            and self.blast_radius_reference is None
            and self.exemption_reference is None
        ):
            raise ValueError("change intent requires blast radius analysis or exemption")
        if self.status is ChangeIntentStatus.DIVERGED and self.divergence_reason is None:
            raise ValueError("diverged change intent requires a reason")
        return self


class ImplementationStep(_ImmutableStudioModel):
    step_id: StableId
    text: str = Field(min_length=1, max_length=500)
    status: StepStatus


class ImplementationTracker(_ImmutableContractModel):
    tracker_id: StableId
    task_id: StableId
    milestone_id: StableId
    owner_instance_id: StableId
    work_package_id: StableId
    base_snapshot: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    current_snapshot: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    goal: str = Field(min_length=1, max_length=500)
    acceptance_references: list[ArtifactReference]
    dependency_ids: list[StableId]
    steps: list[ImplementationStep] = Field(min_length=1, max_length=20)
    tests_planned: list[str]
    tests_added: list[str]
    affected_paths: list[str]
    current_step_id: StableId | None
    next_action: str = Field(min_length=1, max_length=500)
    blocker: str | None = Field(default=None, min_length=1, max_length=500)
    evidence_references: list[ArtifactReference]
    safe_resume_marker_id: StableId
    updated_at: AwareDatetime
    handoff_reference: ArtifactReference | None

    @model_validator(mode="after")
    def validate_tracker(self) -> Self:
        step_ids = [step.step_id for step in self.steps]
        if len(step_ids) != len(set(step_ids)):
            raise ValueError("duplicate implementation step")
        if self.current_step_id is not None and self.current_step_id not in step_ids:
            raise ValueError("current step is not present")
        if any(not _is_safe_repo_locator(path) for path in self.affected_paths):
            raise ValueError("affected paths must be repository-relative")
        return self


class MilestoneProgress(_ImmutableContractModel):
    progress_id: StableId
    milestone_id: StableId
    status: MilestoneProgressStatus
    created_at: AwareDatetime
    updated_at: AwareDatetime
    completed_at: AwareDatetime | None
    base_snapshot: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    current_snapshot: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    readiness_reference: ArtifactReference
    contract_reference: ArtifactReference
    supporting_references: list[ArtifactReference]
    affected_roles: list[str]
    not_applicable_roles: dict[str, str]
    work_package_ids: list[StableId]
    gate_outcomes: dict[str, str]
    evidence_references: list[ArtifactReference]
    latest_safe_resume_marker_id: StableId
    task_trackers: list[ImplementationTracker]
    active_task_ids: list[StableId]

    @model_validator(mode="after")
    def validate_active_state(self) -> Self:
        tracker_ids = {tracker.task_id for tracker in self.task_trackers}
        if not set(self.active_task_ids).issubset(tracker_ids):
            raise ValueError("active task lacks a tracker")
        if self.status is MilestoneProgressStatus.ACTIVE and len(self.active_task_ids) != 1:
            raise ValueError("active milestone must have exactly one active task")
        if self.status is MilestoneProgressStatus.APPROVED and self.completed_at is None:
            raise ValueError("approved milestone progress requires completion time")
        return self
