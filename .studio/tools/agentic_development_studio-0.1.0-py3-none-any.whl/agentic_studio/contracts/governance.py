from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from .planning import ArtifactReference
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class RuleTier(StrEnum):
    OBLIGATION = "obligation"
    HUMAN = "human"
    PROJECT = "project"
    STUDIO = "studio"
    ROLE_SKILL = "role_skill"


class RoleCapabilityKind(StrEnum):
    AUTHORITY = "authority"
    BOUNDARY = "boundary"


class RoleCapabilityEnforcement(StrEnum):
    AGENT_INSTRUCTION = "agent_instruction"
    CONTROL_PLANE = "control_plane"
    HUMAN_GATE = "human_gate"
    RUNTIME_PERMISSION = "runtime_permission"


class EngineeringRule(_ImmutableStudioModel):
    rule_id: StableId
    tier: RuleTier
    statement: str = Field(min_length=1, max_length=1000)
    source: str = Field(min_length=1, max_length=500)
    non_negotiable: bool = False
    affected_roles: list[StableId]


class ResolvedStandardRule(_ImmutableStudioModel):
    rule_id: StableId
    effective_statement: str = Field(min_length=1, max_length=1000)
    winning_tier: RuleTier
    source: str
    shadowed_sources: list[str]
    rationale: str


class StandardsProfile(_ImmutableContractModel):
    profile_id: StableId
    rules: list[EngineeringRule] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_rules(self) -> Self:
        keys = [(rule.rule_id, rule.tier) for rule in self.rules]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate standards rule at the same tier")
        return self


class RoleDefinition(_ImmutableStudioModel):
    role_id: StableId
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(min_length=1, max_length=500)
    authority: list[StableId]
    boundaries: list[StableId]
    required_outputs: list[StableId]
    independent_from: list[StableId]


class RoleCatalog(_ImmutableContractModel):
    catalog_id: StableId
    roles: list[RoleDefinition] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_roles(self) -> Self:
        role_ids = [role.role_id for role in self.roles]
        if len(role_ids) != len(set(role_ids)):
            raise ValueError("duplicate role ID")
        return self


class RoleCapabilityDefinition(_ImmutableStudioModel):
    capability_id: StableId
    kind: RoleCapabilityKind
    definition: str = Field(min_length=1, max_length=500)
    instruction: str = Field(min_length=1, max_length=1000)
    enforcement: list[RoleCapabilityEnforcement] = Field(min_length=1)
    applicable_roles: list[StableId] = Field(min_length=1)


class RoleCapabilityRegistry(_ImmutableContractModel):
    registry_id: StableId
    capabilities: list[RoleCapabilityDefinition] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_capabilities(self) -> Self:
        capability_ids = [item.capability_id for item in self.capabilities]
        if len(capability_ids) != len(set(capability_ids)):
            raise ValueError("duplicate role capability ID")
        return self


class WorkflowPolicy(_ImmutableContractModel):
    policy_id: StableId
    transitions: dict[str, list[str]]
    terminal_states: list[str]


class QualityGate(_ImmutableStudioModel):
    gate_id: StableId
    responsible_role: StableId
    required_evidence: list[str]
    blocking: bool = True


class QualityGatePolicy(_ImmutableContractModel):
    policy_id: StableId
    gates: list[QualityGate] = Field(min_length=1)


class PromptTemplate(_ImmutableContractModel):
    template_id: StableId
    required_sections: list[str] = Field(min_length=1)
    prohibited_content: list[str]
    completion_condition: str = Field(min_length=1, max_length=500)


class StandardsException(_ImmutableContractModel):
    exception_id: StableId
    rule_id: StableId
    scope: str = Field(min_length=1, max_length=500)
    owner: str = Field(min_length=1, max_length=120)
    rationale: str = Field(min_length=1, max_length=1000)
    evidence_references: list[ArtifactReference]
    compensating_controls: list[str] = Field(min_length=1)
    approval_reference: ArtifactReference
    next_review_trigger: str = Field(min_length=1, max_length=500)
    status: str = Field(min_length=1, max_length=120)
