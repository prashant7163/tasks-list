from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import AwareDatetime, Field, model_validator

from .planning import ArtifactReference
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class PreflightOutcome(StrEnum):
    PASS = "pass"
    WARNING = "warning"
    AFFECTED_SCOPE_BLOCKER = "affected_scope_blocker"
    NOT_APPLICABLE = "not_applicable"


class PreflightCheck(_ImmutableStudioModel):
    check_id: StableId
    scope: str = Field(min_length=1, max_length=120)
    outcome: PreflightOutcome
    summary: str = Field(min_length=1, max_length=500)
    owner: str = Field(min_length=1, max_length=120)
    remediation: str | None = Field(default=None, min_length=1, max_length=500)


class PreflightResult(_ImmutableContractModel):
    result_id: StableId
    project_id: StableId
    snapshot_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    recorded_at: AwareDatetime
    checks: list[PreflightCheck] = Field(min_length=1)
    secret_reference_names: list[str]


class OperatorAction(StrEnum):
    PAUSE = "pause"
    CANCEL = "cancel"
    REVOKE_LEASE = "revoke_lease"
    REVOKE_PERMISSION = "revoke_permission"
    QUARANTINE_OUTBOUND = "quarantine_outbound"
    STOP_ALL = "stop_all"


class OperatorControl(_ImmutableContractModel):
    control_id: StableId
    action: OperatorAction
    issued_by: str = Field(min_length=1, max_length=120)
    issued_at: AwareDatetime
    scope: str = Field(min_length=1, max_length=500)
    reason: str = Field(min_length=1, max_length=500)
    graceful_timeout_seconds: int = Field(ge=0, le=3600)


class CapabilityStatus(StrEnum):
    ACTIVE = "active"
    REVOKED = "revoked"
    QUARANTINED = "quarantined"


class ExternalCapability(_ImmutableContractModel):
    capability_id: StableId
    capability_type: str = Field(min_length=1, max_length=120)
    purpose: str = Field(min_length=1, max_length=500)
    source: str = Field(min_length=1, max_length=500)
    version: str = Field(min_length=1, max_length=120)
    digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    license: str = Field(min_length=1, max_length=120)
    minimum_permissions: list[str]
    network_endpoints: list[str]
    data_classifications: list[str]
    consuming_roles: list[StableId]
    integrity_verification: str = Field(min_length=1, max_length=500)
    approval_reference: ArtifactReference | None
    status: CapabilityStatus
    rollback: str = Field(min_length=1, max_length=500)
    review_trigger: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_activation(self) -> Self:
        if self.status is CapabilityStatus.ACTIVE and self.approval_reference is None:
            raise ValueError("active external capability requires approval evidence")
        return self


class ThreatModel(_ImmutableContractModel):
    threat_model_id: StableId
    assets: list[str]
    actors: list[str]
    trust_boundaries: list[str]
    abuse_cases: list[str]
    controls: list[str]
    residual_risks: list[str]
    owner_roles: list[StableId]
    evidence_references: list[ArtifactReference]


class IncidentRecord(_ImmutableContractModel):
    incident_id: StableId
    detected_at: AwareDatetime
    scope: str
    evidence_references: list[ArtifactReference]
    containment_actions: list[str]
    remediation_actions: list[str]
    affected_gate_ids: list[StableId]
    recovery_approval_reference: ArtifactReference | None
    status: str = Field(min_length=1, max_length=120)


class ProjectProvenance(_ImmutableContractModel):
    provenance_id: StableId
    studio_release: str = Field(min_length=1, max_length=120)
    contract_schema_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    adapter_id: StableId
    role_profile_versions: dict[StableId, str]
    skill_versions: dict[StableId, str]
    baseline_version: str = Field(min_length=1, max_length=120)


class UpgradeAssessment(_ImmutableContractModel):
    assessment_id: StableId
    current_release: str = Field(min_length=1, max_length=120)
    target_release: str = Field(min_length=1, max_length=120)
    customization_paths: list[str]
    material: bool
    ordered_migrations: list[str]
    dry_run_evidence_reference: ArtifactReference
    backup_path: str = Field(min_length=1, max_length=500)
    verification: list[str] = Field(min_length=1)
    rollback: list[str] = Field(min_length=1)
    approval_reference: ArtifactReference | None
    status: str = Field(min_length=1, max_length=120)

    @model_validator(mode="after")
    def validate_material_approval(self) -> Self:
        if self.material and self.status == "approved" and self.approval_reference is None:
            raise ValueError("approved material upgrade requires human approval")
        return self
