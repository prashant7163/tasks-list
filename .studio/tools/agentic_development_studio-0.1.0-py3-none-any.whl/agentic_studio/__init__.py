from importlib.metadata import version

__version__ = version("agentic-development-studio")

__all__ = ["__version__"]
