from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from agentic_studio.contracts import GateKind, TaskLifecycle


@dataclass(frozen=True, slots=True)
class ParsedOperation:
    operation: str
    project_root: Path
    parameters: MappingProxyType[str, Any]


def _mutation(parser: argparse.ArgumentParser, *, file_required: bool = True) -> None:
    if file_required:
        parser.add_argument("--file", required=True)
    parser.add_argument("--idempotency-key", required=True)


def _read_run(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--run-id")


def _operation_group(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
    name: str,
    actions: tuple[str, ...],
) -> dict[str, argparse.ArgumentParser]:
    parent = subparsers.add_parser(name)
    nested = parent.add_subparsers(dest="action")
    return {action: nested.add_parser(action) for action in actions}


def studioctl_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="studioctl")
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    commands = parser.add_subparsers(dest="command", required=True)

    run = _operation_group(
        commands,
        "run",
        ("initialize", "import", "list", "select", "inspect", "approve"),
    )
    run["initialize"].add_argument("--run-id")
    run["initialize"].add_argument("--runtime", default="codex")
    _mutation(run["initialize"], file_required=False)
    run["import"].add_argument("--manifest", "--file", dest="file", required=True)
    _mutation(run["import"], file_required=False)
    run["select"].add_argument("selected_run_id", nargs="?")
    run["select"].add_argument("--run-id")
    _mutation(run["select"], file_required=False)
    _read_run(run["inspect"])
    run["approve"].add_argument("--milestone-review-id", required=True)
    run["approve"].add_argument("--milestone-review-sha256", required=True)
    run["approve"].add_argument("--decision", required=True, choices=("approved",))
    run["approve"].add_argument("--decided-by", required=True)
    run["approve"].add_argument("--comment")
    _mutation(run["approve"], file_required=False)

    for name in ("specification", "plan", "evidence", "task", "result"):
        action = _operation_group(commands, name, ("submit",))["submit"]
        _mutation(action)

    readiness = _operation_group(commands, "readiness", ("submit", "inspect"))
    _mutation(readiness["submit"])
    _read_run(readiness["inspect"])

    gate = _operation_group(commands, "gate", ("submit",))["submit"]
    gate.add_argument("--kind", required=True, choices=tuple(GateKind))
    _mutation(gate)

    for name in ("status", "progress", "history"):
        command = commands.add_parser(name)
        _read_run(command)
        if name in {"progress", "history"}:
            command.add_argument("--limit", type=int, default=20)

    explain = commands.add_parser("explain")
    explain.add_argument("current", choices=tuple(TaskLifecycle))
    explain.add_argument("requested", choices=tuple(TaskLifecycle))
    explain.add_argument("--evidence-id", action="append", default=[])

    checkpoint = _operation_group(commands, "checkpoint", ("create", "inspect"))
    _mutation(checkpoint["create"])
    _read_run(checkpoint["inspect"])

    resume = commands.add_parser("resume")
    _mutation(resume)
    resume.add_argument("--resolution-evidence", action="append", default=[])

    retry = commands.add_parser("retry")
    _mutation(retry)
    retry.add_argument("--resolution-evidence", action="append", default=[])

    cancel = commands.add_parser("cancel")
    _mutation(cancel)

    commands.add_parser("projection-rebuild")
    commands.add_parser("context-index-rebuild")

    retention = commands.add_parser("retention")
    _mutation(retention)

    for name in ("export-state", "export-review"):
        export = commands.add_parser(name)
        export.add_argument("destination")
        _read_run(export)

    commands.add_parser("doctor")
    commands.add_parser("conformance")
    commands.add_parser("bootstrap")

    control = _operation_group(commands, "control", ("apply", "clear", "inspect"))
    _mutation(control["apply"])
    control["clear"].add_argument("--control-id", required=True)
    _mutation(control["clear"])

    trust = _operation_group(commands, "trust", ("apply", "inspect"))
    _mutation(trust["apply"])
    trust["apply"].add_argument("--approval-file")
    _read_run(trust["inspect"])

    incident = _operation_group(commands, "incident", ("apply", "inspect"))
    _mutation(incident["apply"])
    _read_run(incident["inspect"])
    return parser


def parse_studioctl(argv: list[str] | tuple[str, ...]) -> ParsedOperation:
    namespace = studioctl_parser().parse_args(argv)
    values = vars(namespace)
    command = str(values.pop("command"))
    action = values.pop("action", None)
    project_root = values.pop("project_root")
    operation = f"{command}.{action}" if action else command
    parameters = {key: value for key, value in values.items() if value is not None}
    return ParsedOperation(
        operation=operation,
        project_root=project_root,
        parameters=MappingProxyType(parameters),
    )
