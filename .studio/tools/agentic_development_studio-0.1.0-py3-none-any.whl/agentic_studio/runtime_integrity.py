from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _locked_runtime_packages(lock: Path) -> dict[str, str]:
    indexed: dict[str, dict[str, Any]] = {}
    for block in lock.read_text(encoding="utf-8").split("[[package]]")[1:]:
        name_match = re.search(r'^name = "([^"]+)"$', block, re.MULTILINE)
        version_match = re.search(r'^version = "([^"]+)"$', block, re.MULTILINE)
        if name_match is None or version_match is None:
            raise ValueError("runtime lock contains an invalid package")
        dependency_section = re.search(
            r"^dependencies = \[\n(?P<body>.*?)^\]$",
            block,
            re.MULTILINE | re.DOTALL,
        )
        dependencies = (
            re.findall(r'{ name = "([^"]+)"', dependency_section.group("body"))
            if dependency_section is not None
            else []
        )
        indexed[name_match.group(1)] = {
            "version": version_match.group(1),
            "dependencies": dependencies,
            "block": block,
        }
    pending = ["agentic-development-studio"]
    selected: dict[str, str] = {}
    while pending:
        name = pending.pop()
        if name in selected:
            continue
        package = indexed.get(name)
        version = None if package is None else package.get("version")
        if package is None or not isinstance(version, str):
            raise ValueError(f"runtime lock is missing a version for {name}")
        selected[name] = version
        dependencies = package.get("dependencies", [])
        if not isinstance(dependencies, list) or not all(
            isinstance(dependency, str) for dependency in dependencies
        ):
            raise ValueError(f"runtime lock dependencies are invalid for {name}")
        pending.extend(dependencies)
    return dict(sorted(selected.items()))


def _locked_runtime_artifact_hashes(lock: Path) -> dict[str, list[str]]:
    selected = _locked_runtime_packages(lock)
    blocks: dict[str, str] = {}
    for block in lock.read_text(encoding="utf-8").split("[[package]]")[1:]:
        name_match = re.search(r'^name = "([^"]+)"$', block, re.MULTILINE)
        if name_match is not None:
            blocks[name_match.group(1)] = block
    hashes: dict[str, list[str]] = {}
    for name in selected:
        if name == "agentic-development-studio":
            continue
        values = sorted(set(re.findall(r'hash = "(sha256:[0-9a-f]{64})"', blocks[name])))
        if not values:
            raise ValueError(f"runtime lock contains no artifact hashes for {name}")
        hashes[name] = values
    return dict(sorted(hashes.items()))


def _installed_versions(python: Path) -> dict[str, str]:
    script = (
        "import importlib.metadata,json;"
        "normalize=lambda name:name.lower().replace('_','-');"
        "versions={normalize(d.metadata['Name']):d.version "
        "for d in importlib.metadata.distributions()};"
        "print(json.dumps(versions,sort_keys=True))"
    )
    completed = subprocess.run(
        [str(python), "-c", script], capture_output=True, text=True, check=False
    )
    if completed.returncode != 0:
        raise ValueError("installed runtime package metadata could not be read")
    payload = json.loads(completed.stdout)
    if not isinstance(payload, dict) or not all(
        isinstance(name, str) and isinstance(version, str) for name, version in payload.items()
    ):
        raise ValueError("installed runtime package metadata is invalid")
    return dict(payload)


def _installed_content(
    python: Path, expected_packages: dict[str, str]
) -> dict[str, dict[str, str]]:
    script = """
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys

normalize = lambda name: name.lower().replace("_", "-")
expected = set(json.loads(sys.argv[1]))
prefix = Path(sys.prefix).resolve()
content = {}
for distribution in importlib.metadata.distributions():
    name = normalize(distribution.metadata["Name"])
    if name not in expected:
        continue
    files = {}
    for entry in distribution.files or ():
        path = Path(distribution.locate_file(entry))
        if not path.is_file() or path.suffix == ".pyc" or "__pycache__" in path.parts:
            continue
        relative = path.resolve().relative_to(prefix).as_posix()
        files[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    content[name] = dict(sorted(files.items()))
if set(content) != expected or any(not files for files in content.values()):
    raise SystemExit("installed package content is incomplete")
print(json.dumps(dict(sorted(content.items())), sort_keys=True))
"""
    completed = subprocess.run(
        [str(python), "-c", script, json.dumps(sorted(expected_packages))],
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        raise ValueError("installed runtime package content could not be hashed")
    payload = json.loads(completed.stdout)
    if not isinstance(payload, dict):
        raise ValueError("installed runtime package content manifest is invalid")
    return payload


def verify_runtime(project_root: Path) -> tuple[bool, str]:
    root = project_root.resolve(strict=True)
    runtime = root / ".studio/runtime"
    python = runtime / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    stamp_path = runtime / "studio-runtime.json"
    if not python.is_file() or not stamp_path.is_file():
        return False, "Project-local runtime or its provenance record is missing."
    try:
        tools = root / ".studio/tools"
        manifest = json.loads((tools / "tool-manifest.json").read_text(encoding="utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError("tool manifest must be an object")
        wheel = tools / str(manifest["wheel"]["file"])
        lock = tools / str(manifest["lock"]["file"])
        wheel_digest = _digest(wheel)
        lock_digest = _digest(lock)
        if wheel_digest != manifest["wheel"]["sha256"]:
            raise ValueError("runtime wheel differs from the tool manifest")
        if lock_digest != manifest["lock"]["sha256"]:
            raise ValueError("runtime lock differs from the tool manifest")
        expected = _locked_runtime_packages(lock)
        artifact_hashes = _locked_runtime_artifact_hashes(lock)
        stamp = json.loads(stamp_path.read_text(encoding="utf-8"))
        if not isinstance(stamp, dict):
            raise ValueError("runtime provenance record must be an object")
        if stamp.get("wheel_sha256") != wheel_digest:
            raise ValueError("runtime wheel provenance differs from the verified bundle")
        if stamp.get("lock_sha256") != lock_digest:
            raise ValueError("runtime lock provenance differs from the verified bundle")
        if stamp.get("packages") != expected:
            raise ValueError("runtime package provenance differs from the exact lock closure")
        if stamp.get("artifact_hashes") != artifact_hashes:
            raise ValueError("runtime artifact provenance differs from the exact lock")
        if _installed_versions(python) != expected:
            raise ValueError("installed runtime packages differ from the exact lock closure")
        if stamp.get("installed_content") != _installed_content(python, expected):
            raise ValueError("installed runtime content differs from its bootstrap manifest")
    except (OSError, UnicodeError, json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
        return False, str(error)[:300]
    return True, "Project-local runtime matches its verified wheel and exact lock closure."
