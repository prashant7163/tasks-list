from __future__ import annotations

from pathlib import PurePosixPath

from agentic_studio.contracts.workflow import Task, TaskLifecycle


class ReadyTaskScheduler:
    def release(self, tasks: list[Task]) -> tuple[Task, ...]:
        ready = sorted(
            (task for task in tasks if task.lifecycle is TaskLifecycle.READY),
            key=lambda task: task.task_id,
        )
        owners: list[tuple[tuple[str, ...], str, str]] = []
        for task in ready:
            for path in task.allowed_paths:
                parts = PurePosixPath(path).parts
                for previous_parts, previous_path, previous_task_id in owners:
                    shared = min(len(parts), len(previous_parts))
                    if parts[:shared] == previous_parts[:shared]:
                        raise ValueError(
                            "overlapping path ownership: "
                            f"{path!r} for {task.task_id!r} overlaps "
                            f"{previous_path!r} for {previous_task_id!r}"
                        )
                owners.append((parts, path, task.task_id))
        return tuple(ready)
