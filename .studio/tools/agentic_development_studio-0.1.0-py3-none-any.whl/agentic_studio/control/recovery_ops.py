from __future__ import annotations

import json
from collections.abc import Callable, Sequence
from datetime import datetime
from pathlib import Path
from typing import Any, cast

from agentic_studio.contracts import (
    ArtifactInput,
    ArtifactKind,
    Checkpoint,
    RegisteredArtifact,
    ResumeMarker,
    ResumeSafety,
    Task,
)
from agentic_studio.persistence import ArtifactRegistry, EventJournal
from agentic_studio.progress import CheckpointStore, RunProjection, checkpoint_digest


def bounded_items[Item](items: Sequence[Item], *, limit: int) -> list[Item]:
    if limit < 0:
        raise ValueError("limit must be non-negative")
    if limit == 0:
        return []
    return list(items[-limit:])


class RecoveryDenied(ValueError):
    pass


class RecoveryOperations:
    def __init__(
        self,
        project_root: Path,
        registry: ArtifactRegistry,
        run: RunProjection,
        *,
        clock: Callable[[], datetime],
        id_factory: Callable[[], str],
    ) -> None:
        self.project_root = project_root
        self.registry = registry
        self.run = run
        self.clock = clock
        self.id_factory = id_factory
        self.checkpoints = CheckpointStore(project_root)

    def _authorized_checkpoint(self, checkpoint_id: str) -> Checkpoint:
        try:
            checkpoint = self.checkpoints.load(self.run.run_id, checkpoint_id)
        except LookupError as error:
            raise RecoveryDenied("Journal-authorized checkpoint is missing or invalid.") from error
        for event in reversed(
            EventJournal(self.project_root / ".studio/journal/events.jsonl").replay()
        ):
            if event.run_id != self.run.run_id or event.event_type != "checkpoint.created":
                continue
            payload = event.model_dump(mode="json")["payload"]
            if payload.get("checkpoint_id") != checkpoint_id:
                continue
            if payload.get("checkpoint_hash") != checkpoint.checkpoint_hash:
                raise RecoveryDenied(
                    "Checkpoint hash does not match its authorizing journal event."
                )
            return checkpoint
        raise RecoveryDenied("Checkpoint has no authorizing journal event.")

    def register(
        self,
        kind: ArtifactKind,
        file: str,
    ) -> tuple[RegisteredArtifact, Checkpoint | ResumeMarker]:
        registered = self.registry.register(ArtifactInput(kind=kind, file=file))
        model = self.registry.load(registered)
        if not isinstance(model, (Checkpoint, ResumeMarker)):
            raise TypeError("recovery artifact has an unexpected type")
        return registered, model

    def save_checkpoint(self, model: Checkpoint) -> Checkpoint:
        if model.project_id != self.run.project_id or model.run_id != self.run.run_id:
            raise RecoveryDenied("Checkpoint project or run ID does not match the active run.")
        if model.journal_sequence != self.run.last_event_sequence:
            raise RecoveryDenied("Checkpoint does not bind the current journal sequence.")
        if model.source_revision != self.run.current_source_revision:
            raise RecoveryDenied("Checkpoint source revision is stale.")
        accepted = {
            (artifact.source_locator, artifact.sha256, artifact.subject_id)
            for artifact in self.run.artifacts
        }
        for reference in model.artifact_references:
            if (reference.locator, reference.sha256, reference.artifact_id) not in accepted:
                raise RecoveryDenied("Checkpoint references unaccepted evidence.")
        try:
            newest = (
                self._authorized_checkpoint(self.run.latest_checkpoint_id)
                if self.run.latest_checkpoint_id is not None
                else None
            )
        except LookupError as error:
            raise RecoveryDenied("Journal-authorized checkpoint is missing or invalid.") from error
        if newest is None:
            if model.previous_checkpoint_hash is not None:
                raise RecoveryDenied("First checkpoint cannot reference a predecessor.")
        elif model.previous_checkpoint_hash != newest.checkpoint_hash:
            raise RecoveryDenied("Checkpoint does not extend the newest valid checkpoint.")
        return self.checkpoints.save(model, previous=newest)

    def newest_checkpoint(self) -> Checkpoint:
        if self.run.latest_checkpoint_id is None:
            raise RecoveryDenied("No journal-authorized checkpoint is available.")
        checkpoint = self._authorized_checkpoint(self.run.latest_checkpoint_id)
        if checkpoint.project_id != self.run.project_id:
            raise RecoveryDenied("Checkpoint project binding is invalid.")
        return checkpoint

    def _load_checkpoint_reference(self, marker: ResumeMarker) -> Checkpoint:
        reference = marker.checkpoint_reference
        if reference is None:
            raise RecoveryDenied("Resume marker has no checkpoint reference.")
        unresolved = self.project_root / reference.locator
        current = self.project_root
        for component in Path(reference.locator).parts:
            current /= component
            if current.is_symlink():
                raise RecoveryDenied("Checkpoint reference contains a symbolic link.")
        candidate = unresolved.resolve(strict=True)
        try:
            candidate.relative_to(self.project_root)
        except ValueError as error:
            raise RecoveryDenied("Checkpoint reference escapes the project root.") from error
        if candidate.is_symlink() or not candidate.is_file():
            raise RecoveryDenied("Checkpoint reference is not a regular file.")
        try:
            checkpoint = Checkpoint.model_validate_json(candidate.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, ValueError) as error:
            raise RecoveryDenied("Checkpoint reference is invalid.") from error
        if (
            checkpoint.checkpoint_id != reference.artifact_id
            or checkpoint.checkpoint_hash != reference.sha256
            or checkpoint.checkpoint_hash != checkpoint_digest(checkpoint)
        ):
            raise RecoveryDenied("Resume marker checkpoint digest or identity does not match.")
        if checkpoint.checkpoint_id != self.run.latest_checkpoint_id:
            raise RecoveryDenied(
                "Resume marker does not reference the latest authorized checkpoint."
            )
        authorized = self._authorized_checkpoint(checkpoint.checkpoint_id)
        if authorized.checkpoint_hash != checkpoint.checkpoint_hash:
            raise RecoveryDenied("Resume checkpoint does not match its authorizing journal event.")
        if checkpoint.project_id != self.run.project_id or checkpoint.run_id != self.run.run_id:
            raise RecoveryDenied("Resume checkpoint belongs to another run.")
        if checkpoint.source_revision != self.run.current_source_revision:
            raise RecoveryDenied("Resume checkpoint source revision is stale.")
        if checkpoint.journal_sequence > self.run.last_event_sequence:
            raise RecoveryDenied("Resume checkpoint references a future journal sequence.")
        return checkpoint

    def validate_resume(
        self,
        marker: ResumeMarker,
        *,
        resolution_evidence_ids: Sequence[str],
    ) -> Checkpoint:
        if marker.classification is ResumeSafety.INVALID:
            raise RecoveryDenied("Invalid resume marker cannot resume a run.")
        checkpoint = self._load_checkpoint_reference(marker)
        if marker.classification is ResumeSafety.CONDITIONAL:
            if not resolution_evidence_ids:
                raise RecoveryDenied(
                    f"Conditional resume requires named evidence for {marker.reason_code}."
                )
            accepted_ids = {
                identifier
                for artifact in self.run.artifacts
                for identifier in (
                    artifact.subject_id,
                    artifact.source_locator,
                    artifact.sha256,
                )
                if identifier is not None
            }
            if not set(resolution_evidence_ids).issubset(accepted_ids):
                raise RecoveryDenied("Conditional resume evidence is not accepted by this run.")
        return checkpoint

    def task_for_retry(self, task_id: str) -> Task:
        for artifact in reversed(self.run.artifacts):
            if artifact.kind is ArtifactKind.TASK and artifact.subject_id == task_id:
                return cast(Task, self.registry.load(artifact))
        raise RecoveryDenied(f"No accepted task exists for retry: {task_id}")

    @staticmethod
    def request_digest(payload: dict[str, Any]) -> str:
        from hashlib import sha256

        encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        return sha256(encoded).hexdigest()
