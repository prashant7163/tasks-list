from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Final

from pydantic import ValidationError

from agentic_studio.contracts import Checkpoint
from agentic_studio.persistence.atomic import atomic_write_text


class CheckpointStore:
    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root

    def _directory(self, run_id: str) -> Path:
        return self.project_root / ".studio" / "runs" / run_id / "checkpoints"

    def path_for(self, checkpoint: Checkpoint) -> Path:
        return self._directory(checkpoint.run_id) / (
            f"{checkpoint.journal_sequence:020d}-{checkpoint.checkpoint_id}.json"
        )

    _AUTO_PREVIOUS: Final = object()

    def save(
        self,
        checkpoint: Checkpoint,
        *,
        previous: Checkpoint | object | None = _AUTO_PREVIOUS,
    ) -> Checkpoint:
        if checkpoint.checkpoint_hash is not None:
            raise ValueError("checkpoint hash is assigned by the store")
        if previous is self._AUTO_PREVIOUS:
            try:
                previous = self.newest_valid(checkpoint.run_id)
            except LookupError:
                previous = None
        if isinstance(previous, Checkpoint):
            if checkpoint.previous_checkpoint_hash != previous.checkpoint_hash:
                raise ValueError("previous checkpoint hash does not match the durable chain")
            if checkpoint.journal_sequence <= previous.journal_sequence:
                raise ValueError("checkpoint journal sequence must advance")
        elif checkpoint.previous_checkpoint_hash is not None:
            raise ValueError("first checkpoint cannot reference a previous checkpoint")
        saved = checkpoint.model_copy(update={"checkpoint_hash": checkpoint_digest(checkpoint)})
        path = self.path_for(saved)
        if path.exists():
            existing_checkpoint = Checkpoint.model_validate_json(path.read_text(encoding="utf-8"))
            if existing_checkpoint == saved:
                return existing_checkpoint
            raise FileExistsError(path)
        atomic_write_text(path, saved.model_dump_json(indent=2) + "\n")
        return saved

    def load(self, run_id: str, checkpoint_id: str) -> Checkpoint:
        directory = self._directory(run_id)
        for path in sorted(directory.glob(f"*-{checkpoint_id}.json"), reverse=True):
            try:
                checkpoint = Checkpoint.model_validate_json(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, ValidationError):
                continue
            if (
                checkpoint.checkpoint_id == checkpoint_id
                and checkpoint.checkpoint_hash == checkpoint_digest(checkpoint)
            ):
                return checkpoint
        raise LookupError("checkpoint is not journal-authorized or valid")

    def newest_valid(self, run_id: str = "run-one") -> Checkpoint:
        directory = self._directory(run_id)
        for path in sorted(directory.glob("*.json"), reverse=True):
            try:
                checkpoint = Checkpoint.model_validate_json(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, ValidationError):
                continue
            if checkpoint.checkpoint_hash == checkpoint_digest(checkpoint):
                return checkpoint
        raise LookupError("no valid checkpoint")


def checkpoint_digest(checkpoint: Checkpoint) -> str:
    return hashlib.sha256(
        checkpoint.canonical_json(exclude={"checkpoint_hash"}).encode("utf-8")
    ).hexdigest()
