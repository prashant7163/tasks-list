from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path

from agentic_studio.contracts import SensitiveFinding, SensitivityClass
from agentic_studio.persistence.atomic import atomic_write_text


@dataclass(frozen=True, slots=True)
class RedactionResult:
    content: str
    findings: tuple[SensitiveFinding, ...]
    blocked: bool


class RedactionEngine:
    _patterns = (
        (
            "credential_field",
            re.compile(
                r"\b(?:api[_-]?key|password|secret|token)\b\s*[:=]\s*[\"'][^\"'\r\n]+[\"']",
                re.IGNORECASE,
            ),
            SensitivityClass.RESTRICTED,
            "high",
        ),
        (
            "aws_access_key",
            re.compile(r"AKIA[0-9A-Z]{16}"),
            SensitivityClass.RESTRICTED,
            "high",
        ),
        (
            "email",
            re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
            SensitivityClass.CONFIDENTIAL,
            "medium",
        ),
    )

    def redact(self, content: str, path: str) -> RedactionResult:
        content_digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
        redacted = content
        findings: list[SensitiveFinding] = []
        for kind, pattern, sensitivity, confidence in self._patterns:
            matches = tuple(pattern.finditer(redacted))
            for index, _ in enumerate(matches, start=1):
                finding_digest = hashlib.sha256(
                    f"{path}\x1f{kind}\x1f{index}\x1f{content_digest}".encode()
                ).hexdigest()[:16]
                findings.append(
                    SensitiveFinding(
                        schema_version="1.0.0",
                        finding_id=f"finding-{finding_digest}",
                        path=path,
                        kind=kind,
                        sensitivity=sensitivity,
                        confidence=confidence,
                        content_digest=content_digest,
                        action="block" if confidence == "high" else "redact",
                    )
                )
            redacted = pattern.sub(f"[REDACTED:{kind}]", redacted)
        return RedactionResult(
            redacted,
            tuple(findings),
            any(finding.action == "block" for finding in findings),
        )


class QuarantineStore:
    def __init__(self, project_root: Path) -> None:
        self.directory = project_root / ".studio" / "security" / "quarantine"

    def record(self, findings: tuple[SensitiveFinding, ...]) -> tuple[Path, ...]:
        paths: list[Path] = []
        for finding in findings:
            path = self.directory / f"{finding.finding_id}.json"
            atomic_write_text(path, finding.model_dump_json(indent=2) + "\n")
            paths.append(path)
        return tuple(paths)

    def metadata_files(self) -> tuple[Path, ...]:
        if not self.directory.exists():
            return ()
        return tuple(sorted(self.directory.glob("*.json")))
