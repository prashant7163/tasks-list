from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import ClassVar

from agentic_studio.persistence.atomic import atomic_write_text

from .redaction import QuarantineStore, RedactionEngine


@dataclass(frozen=True, slots=True)
class FileRecord:
    path: str
    content_hash: str
    size_bytes: int
    language: str
    content: str
    redaction_count: int


@dataclass(frozen=True, slots=True)
class IndexSnapshot:
    revision: str
    records: tuple[FileRecord, ...]
    changed_paths: tuple[str, ...] = ()
    fallback_reason: str | None = None


class RepositoryIndex:
    _excluded_parts: ClassVar[frozenset[str]] = frozenset(
        {".git", ".studio", ".venv", "__pycache__", "dist"}
    )
    _languages: ClassVar[Mapping[str, str]] = {
        ".json": "json",
        ".md": "markdown",
        ".py": "python",
        ".toml": "toml",
        ".yaml": "yaml",
        ".yml": "yaml",
    }

    def __init__(
        self,
        project_root: Path,
        *,
        redactor: RedactionEngine | None = None,
        quarantine: QuarantineStore | None = None,
    ) -> None:
        self.project_root = project_root
        self.redactor = redactor or RedactionEngine()
        self.quarantine = quarantine or QuarantineStore(project_root)

    @staticmethod
    def _revision(records: tuple[FileRecord, ...]) -> str:
        material = "\n".join(f"{record.path}\0{record.content_hash}" for record in records)
        return hashlib.sha256(material.encode("utf-8")).hexdigest()

    def build(self) -> IndexSnapshot:
        records: list[FileRecord] = []
        for path in sorted(self.project_root.rglob("*")):
            relative = path.relative_to(self.project_root)
            if any(part in self._excluded_parts for part in relative.parts):
                continue
            if path.is_symlink() or not path.is_file() or path.suffix not in self._languages:
                continue
            try:
                raw = path.read_text(encoding="utf-8")
            except (OSError, UnicodeError):
                continue
            result = self.redactor.redact(raw, relative.as_posix())
            if result.blocked:
                self.quarantine.record(result.findings)
                continue
            records.append(
                FileRecord(
                    path=relative.as_posix(),
                    content_hash=hashlib.sha256(raw.encode("utf-8")).hexdigest(),
                    size_bytes=len(result.content.encode("utf-8")),
                    language=self._languages[path.suffix],
                    content=result.content,
                    redaction_count=len(result.findings),
                )
            )
        frozen = tuple(records)
        return IndexSnapshot(self._revision(frozen), frozen)

    def refresh(self, previous: IndexSnapshot) -> IndexSnapshot:
        current = self.build()
        old = {record.path: record.content_hash for record in previous.records}
        new = {record.path: record.content_hash for record in current.records}
        changed = tuple(
            sorted(path for path in old.keys() | new.keys() if old.get(path) != new.get(path))
        )
        return replace(current, changed_paths=changed)

    def save(self, snapshot: IndexSnapshot, path: Path) -> None:
        payload = {
            "revision": snapshot.revision,
            "records": [asdict(record) for record in snapshot.records],
        }
        atomic_write_text(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")

    def load(self, path: Path) -> IndexSnapshot:
        payload = json.loads(path.read_text(encoding="utf-8"))
        records = tuple(FileRecord(**record) for record in payload["records"])
        snapshot = IndexSnapshot(payload["revision"], records)
        if snapshot.revision != self._revision(records):
            raise ValueError("index revision does not match records")
        return snapshot

    def load_or_rebuild(self, path: Path) -> IndexSnapshot:
        try:
            cached = self.load(path)
        except (OSError, UnicodeError, ValueError, KeyError, TypeError, json.JSONDecodeError):
            rebuilt = replace(self.build(), fallback_reason="cache_invalid_rebuilt")
            self.save(rebuilt, path)
            return rebuilt
        current = self.build()
        if current.revision != cached.revision:
            rebuilt = replace(current, fallback_reason="cache_stale_rebuilt")
            self.save(rebuilt, path)
            return rebuilt
        return cached
