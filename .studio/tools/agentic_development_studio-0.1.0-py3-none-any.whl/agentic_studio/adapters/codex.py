from __future__ import annotations

import json
import tomllib
from pathlib import Path

from agentic_studio.contracts import RoleCapabilityRegistry, RoleCatalog, RoleDefinition

from .base import RuntimeCapabilities


class CodexNativeMapping:
    _read_only_roles = frozenset({"code-reviewer", "independent-auditor"})

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root

    @property
    def capabilities(self) -> RuntimeCapabilities:
        roles = tuple(
            path.stem for path in sorted((self.project_root / ".codex" / "agents").glob("*.toml"))
        )
        return RuntimeCapabilities(
            runtime_id="codex",
            native_delegation=True,
            durable_provider_threads=False,
            control_plane_authoritative=True,
            supported_roles=roles,
        )

    def role_file(self, role_id: str) -> Path:
        path = self.project_root / ".codex" / "agents" / f"{role_id}.toml"
        if not path.is_file():
            raise LookupError(role_id)
        return path

    def write_role_files(
        self,
        role_catalog: RoleCatalog,
        capability_registry: RoleCapabilityRegistry,
    ) -> None:
        agents = self.project_root / ".codex" / "agents"
        agents.mkdir(parents=True, exist_ok=True)
        expected_names = {f"{role.role_id}.toml" for role in role_catalog.roles}
        for existing in agents.glob("*.toml"):
            if existing.name not in expected_names:
                existing.unlink()
        for role in role_catalog.roles:
            (agents / f"{role.role_id}.toml").write_text(
                self.render_role(role, capability_registry),
                encoding="utf-8",
            )

    def validation_errors(
        self,
        role_catalog: RoleCatalog,
        capability_registry: RoleCapabilityRegistry,
    ) -> tuple[str, ...]:
        agents = self.project_root / ".codex" / "agents"
        expected_names = {f"{role.role_id}.toml" for role in role_catalog.roles}
        actual_names = {path.name for path in agents.glob("*.toml")} if agents.is_dir() else set()
        errors = [
            *(f"missing agent file: {name}" for name in sorted(expected_names - actual_names)),
            *(f"unexpected agent file: {name}" for name in sorted(actual_names - expected_names)),
        ]
        for role in role_catalog.roles:
            path = agents / f"{role.role_id}.toml"
            if not path.is_file():
                continue
            try:
                actual = tomllib.loads(path.read_text(encoding="utf-8"))
                expected = tomllib.loads(self.render_role(role, capability_registry))
            except (OSError, UnicodeError, tomllib.TOMLDecodeError) as error:
                errors.append(f"invalid agent file {path.name}: {error}")
                continue
            if actual != expected:
                errors.append(f"agent policy drift: {path.name}")
        return tuple(errors)

    @classmethod
    def render_role(
        cls,
        role: RoleDefinition,
        capability_registry: RoleCapabilityRegistry,
    ) -> str:
        capabilities = {
            capability.capability_id: capability for capability in capability_registry.capabilities
        }
        lines = [
            f"You are the {role.name}.",
            role.description,
            "",
            "Authorities:",
            *(
                f"- {capability_id}: {capabilities[capability_id].instruction}"
                for capability_id in role.authority
            ),
            "",
            "Boundaries:",
            *(
                f"- {capability_id}: {capabilities[capability_id].instruction}"
                for capability_id in role.boundaries
            ),
            "",
            f"Required outputs: {', '.join(role.required_outputs)}.",
            "Follow AGENTS.md and the project-local governance. Stay within these authorities "
            "and boundaries. Return out-of-scope or blocked work to the Orchestrator.",
        ]
        settings = [
            f"name = {json.dumps(role.name)}",
            f"description = {json.dumps(role.description)}",
        ]
        if role.role_id in cls._read_only_roles:
            settings.append('sandbox_mode = "read-only"')
        settings.append(f"developer_instructions = {json.dumps(chr(10).join(lines))}")
        return "\n".join(settings) + "\n"
