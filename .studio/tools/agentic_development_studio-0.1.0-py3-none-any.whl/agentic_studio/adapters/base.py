from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from agentic_studio.contracts import Handoff, TaskResult


@dataclass(frozen=True, slots=True)
class RuntimeCapabilities:
    runtime_id: str
    native_delegation: bool
    durable_provider_threads: bool
    control_plane_authoritative: bool
    supported_roles: tuple[str, ...]


class RuntimeAdapter(Protocol):
    @property
    def capabilities(self) -> RuntimeCapabilities: ...

    def dispatch(self, handoff: Handoff) -> str: ...

    def collect_result(self, invocation_id: str) -> TaskResult: ...

    def cancel(self, invocation_id: str) -> None: ...
