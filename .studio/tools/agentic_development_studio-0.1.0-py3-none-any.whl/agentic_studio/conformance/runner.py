from __future__ import annotations

import json
import shutil
import tempfile
from contextlib import redirect_stdout
from dataclasses import asdict, dataclass
from io import StringIO
from pathlib import Path

import yaml

from agentic_studio.adapters.codex import CodexNativeMapping
from agentic_studio.contracts import StudioConfig, TaskLifecycle
from agentic_studio.control.governance import CanonicalAssetLoader
from agentic_studio.control.lifecycle import LifecycleController
from agentic_studio.persistence.atomic import atomic_write_text


@dataclass(frozen=True, slots=True)
class ScenarioResult:
    scenario_id: str
    outcome: str
    summary: str


@dataclass(frozen=True, slots=True)
class ConformanceReport:
    framework: str
    runtime: str
    passed: bool
    scenarios: tuple[ScenarioResult, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "framework": self.framework,
            "runtime": self.runtime,
            "passed": self.passed,
            "scenarios": [asdict(scenario) for scenario in self.scenarios],
        }


class ConformanceRunner:
    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root

    def run(self, *, write: bool = True) -> ConformanceReport:
        scenarios = (
            self._configuration(),
            self._codex_runtime(),
            self._clean_state(),
            self._cli_behavioral_surface(),
            self._governance_assets(),
            self._lifecycle_policy(),
            self._approval_isolation(),
            self._context_redaction(),
            self._recovery(),
            self._prompt_quality(),
            self._contract_surface(),
            self._operator_guide(),
        )
        report = ConformanceReport(
            framework="agentic-development-studio-stage-one",
            runtime="codex",
            passed=all(scenario.outcome == "pass" for scenario in scenarios),
            scenarios=scenarios,
        )
        if write:
            atomic_write_text(
                self.project_root / "conformance.json",
                json.dumps(report.as_dict(), indent=2, sort_keys=True) + "\n",
                mode=0o644,
            )
            lines = [
                "# Conformance report",
                "",
                f"Overall: {'PASS' if report.passed else 'FAIL'}",
                "",
            ]
            lines.extend(
                f"- {scenario.scenario_id}: {scenario.outcome.upper()} — {scenario.summary}"
                for scenario in scenarios
            )
            atomic_write_text(
                self.project_root / "conformance.md", "\n".join(lines) + "\n", mode=0o644
            )
        return report

    def _configuration(self) -> ScenarioResult:
        try:
            payload = yaml.safe_load(
                (self.project_root / "studio.yaml").read_text(encoding="utf-8")
            )
            config = StudioConfig.model_validate(payload)
            passed = config.selected_runtime == "codex"
        except Exception:
            passed = False
        return ScenarioResult(
            "configuration",
            "pass" if passed else "fail",
            "studio.yaml selects a schema-valid Codex runtime."
            if passed
            else "Invalid studio.yaml.",
        )

    def _codex_runtime(self) -> ScenarioResult:
        agents = self.project_root / ".codex" / "agents"
        required = {
            "orchestrator-tech-lead",
            "discovery-lead",
            "architect",
            "ux-ui-designer",
            "frontend-engineer",
            "backend-engineer",
            "mobile-developer",
            "code-reviewer",
            "build-manager",
            "quality-engineer",
            "independent-auditor",
        }
        present = {path.stem for path in agents.glob("*.toml")} if agents.is_dir() else set()
        forbidden = {"langgraph", "crewai", "agents-sdk"}
        paths = {path.as_posix().lower() for path in self.project_root.rglob("*")}
        try:
            assets = CanonicalAssetLoader().load_tree(self.project_root / "shared")
            policy_errors = CodexNativeMapping(self.project_root).validation_errors(
                assets.role_catalog,
                assets.capability_registry,
            )
        except Exception:
            policy_errors = ("canonical role policy is invalid",)
        passed = (
            (self.project_root / "AGENTS.md").is_file()
            and (self.project_root / ".codex" / "config.toml").is_file()
            and required == present
            and not any(name in path for name in forbidden for path in paths)
            and not policy_errors
        )
        return ScenarioResult(
            "codex-runtime",
            "pass" if passed else "fail",
            "Codex overlay and role map are complete and exclusive."
            if passed
            else "Codex overlay is missing, incomplete, or contaminated.",
        )

    def _clean_state(self) -> ScenarioResult:
        state = self.project_root / ".studio"
        mutable_roots = ("runs", "context", "security", "journal", "projection", "sessions")
        pristine = state.is_dir() and all(
            not any(path.is_file() for path in (state / name).rglob("*"))
            for name in mutable_roots
            if (state / name).exists()
        )
        live = False
        if state.is_dir() and not pristine:
            try:
                from agentic_studio.persistence import EventJournal
                from agentic_studio.progress import ProjectionStore

                config = StudioConfig.model_validate(
                    yaml.safe_load((self.project_root / "studio.yaml").read_text(encoding="utf-8"))
                )
                events = EventJournal(state / "journal/events.jsonl").replay()
                projection = ProjectionStore(self.project_root).load_or_rebuild()
                live = (
                    bool(events)
                    and projection.last_event_sequence == events[-1].sequence
                    and all(event.project_id == config.project_id for event in events)
                )
            except Exception:
                live = False
        passed = pristine or live
        return ScenarioResult(
            "clean-state",
            "pass" if passed else "fail",
            (
                "Generated runtime stores contain no carried state."
                if pristine
                else "Live runtime state is journal-backed and belongs to this project."
            )
            if passed
            else "Runtime stores contain state that is not valid for this project.",
        )

    def _cli_behavioral_surface(self) -> ScenarioResult:
        from agentic_studio.cli import StudioCtlMain
        from agentic_studio.cli_parser import parse_studioctl
        from agentic_studio.contracts import ResultCode
        from agentic_studio.runtime_integrity import verify_runtime

        passed = False
        try:
            with tempfile.TemporaryDirectory(prefix="studio-conformance-") as temporary:
                project = Path(temporary) / "project"
                shutil.copytree(self.project_root, project)
                runner = StudioCtlMain()
                initialized = runner.execute(
                    parse_studioctl(
                        [
                            "--project-root",
                            str(project),
                            "run",
                            "initialize",
                            "--run-id",
                            "conformance-run",
                            "--idempotency-key",
                            "conformance-init",
                        ]
                    )
                )
                status = runner.execute(parse_studioctl(["--project-root", str(project), "status"]))
                denial = runner.execute(
                    parse_studioctl(
                        [
                            "--project-root",
                            str(project),
                            "explain",
                            "ready",
                            "quality_review",
                        ]
                    )
                )
                missing = "docs/conformance-missing.json"
                evidence = "evidence/conformance.json"
                evidence_path = project / evidence
                evidence_path.parent.mkdir(parents=True, exist_ok=True)
                evidence_path.write_text('{"evidence_id":"conformance"}\n', encoding="utf-8")
                probes = (
                    ["run", "list"],
                    ["run", "select", "conformance-run", "--idempotency-key", "probe-select"],
                    ["run", "inspect", "--run-id", "conformance-run"],
                    [
                        "run",
                        "approve",
                        "--milestone-review-id",
                        "review-missing",
                        "--milestone-review-sha256",
                        "a" * 64,
                        "--decision",
                        "approved",
                        "--decided-by",
                        "conformance",
                        "--idempotency-key",
                        "probe-approve",
                    ],
                    ["run", "import", "--manifest", missing, "--idempotency-key", "probe-import"],
                    *(
                        [
                            family,
                            "submit",
                            "--file",
                            missing,
                            "--idempotency-key",
                            f"probe-{family}",
                        ]
                        for family in (
                            "specification",
                            "plan",
                            "readiness",
                            "task",
                            "result",
                        )
                    ),
                    [
                        "evidence",
                        "submit",
                        "--file",
                        evidence,
                        "--idempotency-key",
                        "probe-evidence",
                    ],
                    [
                        "gate",
                        "submit",
                        "--kind",
                        "code-review",
                        "--file",
                        missing,
                        "--idempotency-key",
                        "probe-gate",
                    ],
                    ["readiness", "inspect", "--run-id", "conformance-run"],
                    ["status"],
                    ["history"],
                    ["progress"],
                    ["explain", "blocked", "ready"],
                    [
                        "checkpoint",
                        "create",
                        "--file",
                        missing,
                        "--idempotency-key",
                        "probe-checkpoint",
                    ],
                    ["checkpoint", "inspect", "--run-id", "conformance-run"],
                    ["resume", "--file", missing, "--idempotency-key", "probe-resume"],
                    ["retry", "--file", missing, "--idempotency-key", "probe-retry"],
                    ["cancel", "--file", missing, "--idempotency-key", "probe-cancel"],
                    ["projection-rebuild"],
                    ["context-index-rebuild"],
                    ["retention", "--file", missing, "--idempotency-key", "probe-retention"],
                    ["export-state", "conformance-state"],
                    ["export-review", "conformance-review"],
                    ["doctor"],
                    ["control", "apply", "--file", missing, "--idempotency-key", "probe-control"],
                    [
                        "control",
                        "clear",
                        "--control-id",
                        "control-missing",
                        "--file",
                        missing,
                        "--idempotency-key",
                        "probe-control-clear",
                    ],
                    ["control", "inspect"],
                    ["trust", "apply", "--file", missing, "--idempotency-key", "probe-trust"],
                    ["trust", "inspect"],
                    ["incident", "apply", "--file", missing, "--idempotency-key", "probe-incident"],
                    ["incident", "inspect"],
                )
                expected_codes = {
                    "run.list": ResultCode.OK,
                    "run.select": ResultCode.OK,
                    "run.inspect": ResultCode.OK,
                    "run.approve": ResultCode.POLICY_DENIED,
                    "run.import": ResultCode.INVALID_INPUT,
                    "specification.submit": ResultCode.INVALID_INPUT,
                    "plan.submit": ResultCode.INVALID_INPUT,
                    "evidence.submit": ResultCode.OK,
                    "readiness.submit": ResultCode.INVALID_INPUT,
                    "task.submit": ResultCode.INVALID_INPUT,
                    "result.submit": ResultCode.INVALID_INPUT,
                    "gate.submit": ResultCode.INVALID_INPUT,
                    "readiness.inspect": ResultCode.OK,
                    "status": ResultCode.OK,
                    "history": ResultCode.OK,
                    "progress": ResultCode.OK,
                    "explain": ResultCode.POLICY_DENIED,
                    "checkpoint.create": ResultCode.INVALID_INPUT,
                    "checkpoint.inspect": ResultCode.POLICY_DENIED,
                    "resume": ResultCode.INVALID_INPUT,
                    "retry": ResultCode.INVALID_INPUT,
                    "cancel": ResultCode.INVALID_INPUT,
                    "projection-rebuild": ResultCode.OK,
                    "context-index-rebuild": ResultCode.OK,
                    "retention": ResultCode.INVALID_INPUT,
                    "export-state": ResultCode.OK,
                    "export-review": ResultCode.OK,
                    "doctor": (
                        ResultCode.OK if verify_runtime(project)[0] else ResultCode.POLICY_DENIED
                    ),
                    "control.apply": ResultCode.INVALID_INPUT,
                    "control.clear": ResultCode.POLICY_DENIED,
                    "control.inspect": ResultCode.OK,
                    "trust.apply": ResultCode.INVALID_INPUT,
                    "trust.inspect": ResultCode.OK,
                    "incident.apply": ResultCode.INVALID_INPUT,
                    "incident.inspect": ResultCode.OK,
                }
                observed_operations = set()
                observed_codes = {}
                for arguments in probes:
                    operation = parse_studioctl(arguments).operation
                    observed_operations.add(operation)
                    output = StringIO()
                    with redirect_stdout(output):
                        runner(["--project-root", str(project), *arguments])
                    payload = json.loads(output.getvalue())
                    observed_codes[operation] = payload.get("code")
                covered_families = {
                    operation.split(".", maxsplit=1)[0] for operation in observed_operations
                }
                passed = (
                    initialized.code is ResultCode.OK
                    and status.code is ResultCode.OK
                    and status.state is not None
                    and status.state.get("phase") == "discovery"
                    and denial.code is ResultCode.POLICY_DENIED
                    and covered_families | {"bootstrap", "conformance"}
                    == set(StudioCtlMain.command_names)
                    and observed_codes == expected_codes
                )
        except Exception:
            passed = False
        return ScenarioResult(
            "cli-behavioral-surface",
            "pass" if passed else "fail",
            (
                "CLI initialization, replayed status, parsing, and safe denial execute."
                if passed
                else "CLI behavioral commands did not produce governed outcomes."
            ),
        )

    def _governance_assets(self) -> ScenarioResult:
        try:
            assets = CanonicalAssetLoader().load_tree(self.project_root / "shared")
            passed = len(assets.quality_gate_policy.gates) == 14
        except Exception:
            passed = False
        return ScenarioResult(
            "governance-assets",
            "pass" if passed else "fail",
            "Canonical governance assets validate." if passed else "Governance assets are invalid.",
        )

    def _contract_surface(self) -> ScenarioResult:
        contracts = tuple((self.project_root / "shared" / "contracts").glob("*.schema.json"))
        required = {"task.schema.json", "checkpoint.schema.json", "context-pack.schema.json"}
        passed = len(contracts) >= 50 and required.issubset({path.name for path in contracts})
        return ScenarioResult(
            "contract-surface",
            "pass" if passed else "fail",
            "Runtime-neutral schemas are present."
            if passed
            else "Contract schemas are incomplete.",
        )

    def _lifecycle_policy(self) -> ScenarioResult:
        try:
            policy = CanonicalAssetLoader().load_tree(self.project_root / "shared").workflow_policy
            controller = LifecycleController.from_policy(policy)
            passed = (
                controller.decide(TaskLifecycle.READY, TaskLifecycle.CLAIMED).allowed
                and not controller.decide(TaskLifecycle.READY, TaskLifecycle.QUALITY_REVIEW).allowed
            )
        except Exception:
            passed = False
        return ScenarioResult(
            "lifecycle-policy",
            "pass" if passed else "fail",
            "Closed lifecycle policy blocks gate skipping."
            if passed
            else "Lifecycle policy is invalid or permits a skipped gate.",
        )

    def _approval_isolation(self) -> ScenarioResult:
        reviewer = self.project_root / ".codex" / "agents" / "code-reviewer.toml"
        auditor = self.project_root / ".codex" / "agents" / "independent-auditor.toml"
        approval = self.project_root / "shared" / "contracts" / "approval.schema.json"
        reviewer_text = reviewer.read_text(encoding="utf-8") if reviewer.is_file() else ""
        auditor_text = auditor.read_text(encoding="utf-8") if auditor.is_file() else ""
        passed = (
            approval.is_file()
            and "cannot-review-own-work" in reviewer_text
            and "cannot-audit-own-work" in auditor_text
            and "report-only-to-orchestrator" in auditor_text
            and "cannot-dispatch-remediation" in auditor_text
        )
        return ScenarioResult(
            "approval-isolation",
            "pass" if passed else "fail",
            "Approval and assurance separation are explicit."
            if passed
            else "Approval or assurance independence is incomplete.",
        )

    def _context_redaction(self) -> ScenarioResult:
        required = {
            "context-query.schema.json",
            "context-pack.schema.json",
            "sensitive-finding.schema.json",
            "outbound-manifest.schema.json",
        }
        contracts = self.project_root / "shared" / "contracts"
        skills = (self.project_root / "shared" / "skills" / "catalog.yaml").read_text(
            encoding="utf-8"
        )
        passed = required.issubset({path.name for path in contracts.glob("*.json")}) and all(
            skill in skills for skill in ("context-provenance", "redaction-data-handling")
        )
        return ScenarioResult(
            "context-redaction",
            "pass" if passed else "fail",
            "Context provenance and pre-outbound redaction controls are installed."
            if passed
            else "Context or redaction controls are incomplete.",
        )

    def _recovery(self) -> ScenarioResult:
        contracts = self.project_root / "shared" / "contracts"
        required = {
            "event.schema.json",
            "checkpoint.schema.json",
            "resume-marker.schema.json",
            "worker-lease.schema.json",
            "session.schema.json",
        }
        passed = required.issubset({path.name for path in contracts.glob("*.json")})
        return ScenarioResult(
            "recovery",
            "pass" if passed else "fail",
            "Journal, session, lease, checkpoint, and resume contracts are installed."
            if passed
            else "Recovery contract surface is incomplete.",
        )

    def _prompt_quality(self) -> ScenarioResult:
        try:
            prompt = CanonicalAssetLoader().load_tree(self.project_root / "shared").prompt_template
            required = {
                "objective",
                "authoritative_context",
                "scope_and_permissions",
                "expected_output",
                "verification_evidence",
                "completion_condition",
            }
            passed = required.issubset(prompt.required_sections) and bool(prompt.prohibited_content)
        except Exception:
            passed = False
        return ScenarioResult(
            "prompt-quality",
            "pass" if passed else "fail",
            "Bounded model requests require evidence and prohibit unsafe filler."
            if passed
            else "Model request policy is incomplete.",
        )

    def _operator_guide(self) -> ScenarioResult:
        handbook = self.project_root / "docs" / "project-guide" / "operator-handbook.md"
        runtime = self.project_root / "docs" / "project-guide" / "runtimes" / "codex.md"
        passed = handbook.is_file() and runtime.is_file()
        return ScenarioResult(
            "operator-guide",
            "pass" if passed else "fail",
            "Project-local operator and Codex guides are installed."
            if passed
            else "Project-local operator guidance is incomplete.",
        )
