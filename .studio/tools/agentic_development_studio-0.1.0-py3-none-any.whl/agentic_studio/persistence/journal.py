from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from agentic_studio.contracts import Event

from .atomic import atomic_write_text
from .locking import exclusive_file_lock


class JournalCorruptionError(RuntimeError):
    pass


class EventJournal:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock_path = path.with_suffix(f"{path.suffix}.lock")

    @staticmethod
    def _event_hash(event: Event) -> str:
        payload = event.canonical_json(exclude={"event_hash"})
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _replay_unlocked(self) -> tuple[Event, ...]:
        if not self.path.exists():
            return ()
        try:
            raw = self.path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            raise JournalCorruptionError("journal is unreadable") from error
        if raw and not raw.endswith("\n"):
            raise JournalCorruptionError("journal has a torn final record")
        events: list[Event] = []
        previous_hash: str | None = None
        for expected_sequence, line in enumerate(raw.splitlines(), start=1):
            try:
                event = Event.model_validate_json(line)
            except ValidationError as error:
                raise JournalCorruptionError("journal contains an invalid event") from error
            if event.sequence != expected_sequence:
                raise JournalCorruptionError("journal sequence is not contiguous")
            if event.previous_hash != previous_hash:
                raise JournalCorruptionError("journal previous hash does not match")
            if event.event_hash is None or event.event_hash != self._event_hash(event):
                raise JournalCorruptionError("journal event hash does not match")
            previous_hash = event.event_hash
            events.append(event)
        return tuple(events)

    def replay(self) -> tuple[Event, ...]:
        with exclusive_file_lock(self.lock_path):
            return self._replay_unlocked()

    def record(self, **event_fields: Any) -> Event:
        return self.record_many([event_fields])[0]

    def record_many(self, event_fields: Sequence[Mapping[str, Any]]) -> tuple[Event, ...]:
        if not event_fields:
            raise ValueError("journal batch requires at least one event")
        with exclusive_file_lock(self.lock_path):
            existing_events = self._replay_unlocked()
            previous_hash = existing_events[-1].event_hash if existing_events else None
            prepared: list[Event] = []
            for offset, fields in enumerate(event_fields, start=1):
                event = Event.model_validate(
                    {
                        **fields,
                        "sequence": len(existing_events) + offset,
                        "previous_hash": previous_hash,
                        "event_hash": None,
                    }
                )
                event = event.model_copy(update={"event_hash": self._event_hash(event)})
                prepared.append(event)
                previous_hash = event.event_hash

            existing = self.path.read_text(encoding="utf-8") if self.path.exists() else ""
            lines = "".join(
                json.dumps(event.model_dump(mode="json"), separators=(",", ":"), sort_keys=True)
                + "\n"
                for event in prepared
            )
            atomic_write_text(self.path, f"{existing}{lines}")
            return tuple(prepared)
